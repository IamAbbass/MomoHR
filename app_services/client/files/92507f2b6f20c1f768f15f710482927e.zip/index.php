<html>
	<head>
		<title>Account kit By Facebook - HackerRahul</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	</head>
	
	<body>
	<div class="w3-container w3-blue">
		<h1 class="w3-center">Account kit By Facebook</h1>
	</div><br>
	<h3 class="w3-center">Just Tap the button below and login through sms.<br> <b>OR</b> <br>you can also use this to verify the mobile no. of users...</h3>

	<br>
	
	<div class="w3-container w3-center">
		<form method="get" action="https://www.accountkit.com/v1.0/basic/dialog/sms_login/">
			<input type="hidden" name="app_id" value="2358143771075937">
			<!-- <input type="hidden" name="redirect" value="http://demo.hackerrahul.com/accountkit/callback.php"> -->
			<input type="hidden" name="redirect" value="http://localhost/fb_validation/callback.php">
			<input type="hidden" name="state" value="faraz">
			<input type="hidden" name="fbAppEventsEnabled" value=true>
			<button type="submit" class="w3-button w3-ripple w3-round w3-hover-blue w3-blue">Login with sms</button>
		</form>

	</div>	
	</body>

</html>