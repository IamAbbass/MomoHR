<?php

  $im = imagegrabscreen();
  imagepng($im, "myshot.png");
  imagedestroy($im);

?>
