<?php
  $im = imagegrabscreen();
  $imgName = 'myshot'.time().'.png';
  imagepng($im, $imgName);
  imagedestroy($im);

  $myImage =   file_get_contents($imgName);
  $base64 = base64_encode($myImage);
  echo $base64;

?>




