
var current_page_id 		= null;//default page
var current_ch_id			= null;

var reply_to                = null;
var reply_msg_id            = null;
var reply_attachment        = null;
var reply_sender            = null;
var reply_message           = null;
var wait_for_new_group      = false;
var global_group_id         = null;

var users_split             = "";

var edit_id                 = null;
var del_id                  = null;

var default_type 			= null;

//variables
ajax_get_users              = [];

var reply_intervals     	= [];
var reply_intervals_i   	= 0;

var refresh_users_allow     = true;
var count_select            = [];

//to get only updated chatheads
var timestamp               = 0;
var json_key                = 0;
var unread 					= []; //count of unread messages
var message_callback 		= [];
var ch_filter				= null;

var domain					= "https://momohr.co/";
var base_url 				= domain+"app_services/";

var global_number			= null;
var global_id				= null;
var global_name				= null;
var	global_photo			= null;
var office_name				= null;
var verification_code 		= null;
var play_sound_repeated 	= null;
var firebase_verificationId = null;
var watch_incomming_sms		= false;

var loading_img 		= domain+"img/load-sm.gif";
var loading_img_xs		= domain+"img/load-xs.gif";
var default_group_dp 	= domain+"app_services/admin/assets/default/group.png";
var file_audio			= domain+"img/audio.png";
var file_pdf			= domain+"img/pdf.png";
var file_zip            = domain+"img/zip.png";
var file_video			= domain+"img/video.png";
var file_file			= domain+"img/file.png";

var current_attachment_type = null;


function readURL(input,elem) {
	$(elem).attr('src', loading_img);
    $(elem).show();

    if (input.files && input.files[0]) {
		var reader = new FileReader();
		reader.onload = function (e) {
			var img = e.target.result;
			if(img.substr(5,5) == "image"){
				$(elem).attr('src', e.target.result);
				$(elem).hide().show();
			}
		};
		reader.readAsDataURL(input.files[0]);
	}else {
		var img = input.value;
		$(elem).attr('src',img);
		$(elem).hide().show();
	}
}

function navigate_page(page_id){
	$("#login_screen").hide();

	$(".user_container").hide();
	$(".chat-box").hide();

	$(".dashboard_head").hide();
	$(".profile_head").hide();
	$(".expense_refund_head").hide();
	$("#profile").hide();
	$("#debug_sync").hide();
	$("#debug_url").hide();
	$("#debug_remote").hide();
	$("#expense_list").hide();
	$("#group_info").hide();
	$("#attendance").hide();
	$("#updateVersion").hide();
	$(".attendance_head").hide();
	$(".update_head").hide();
	$(".timeoff_head").hide();
	$("#timeoff").hide();
	$("#chat_heading, .chat-footer").hide();

	$("#"+page_id).show();
	if(page_id == "profile"){
		$(".profile_head").show();
	}else if(page_id == "dashboard"){
		$(".user_container").show();
		current_ch_id = null;
		$(".chat-box").show();
		$(".chat-box .chat-messages").hide();
		$(".dashboard_head").show();

		$(".left_menu .menu-selected").removeClass("menu-selected");
		$(".menu_btn_chat").addClass("menu-selected");

		//apply_filter(ch_filter);
	}else if(page_id == "chat"){
		$(".user_container").show();
		$("#chat_heading, .chat-footer, .chat-box").show();
	}else if(page_id == "debug_sync"){
		$(".profile_head").show();
	}else if(page_id == "debug_url"){
		$(".profile_head").show();
	}else if(page_id == "debug_remote"){
		$(".profile_head").show();
	}else if(page_id == "expense_list"){
		$(".expense_refund_head").show();
	}else if(page_id == "group_info"){
		$(".profile_head").show();
	}else if(page_id == "attendance"){
		$(".attendance_head").show();
	}else if(page_id == "attendance"){
		$(".attendance_head").show();
	}else if(page_id == "timeoff"){
		$(".timeoff_head").show();
	}


	else if(page_id == "updateVersion"){
		$(".update_head").show();
	}
	current_page_id = page_id;
}
function go_back(){

	if(global_id == null){//user not logged in
		if(current_page_id == "quick_login"){
			//window.plugins.appMinimize.minimize();
		}else if(current_page_id == "login_other_phone"){
			//window.plugins.appMinimize.minimize();
		}else if(current_page_id == "new_pin_form"){
			$(".go_back_login").click();
		}else if(current_page_id == "sms_auth_form"){
			$(".go_back_login").click();
		}else{
			//window.plugins.appMinimize.minimize();
		}
	}else{//user logged in
		if(current_page_id == "dashboard"){
			//window.plugins.appMinimize.minimize();
		}else{
			navigate_page("dashboard");
		}
	}
}


		var document_width 			= $(document).width();
		var document_height 		= $(document).height();

		function user_login(data){
			global_number 	= data.input;
			global_id		= data.id;
			global_name		= data.name;
			global_photo	= data.photo;
			office_name		= data.office;

			//storage
			localStorage.setItem("input",data.input);
			localStorage.setItem("id",data.id);
			localStorage.setItem("name",data.name);
			localStorage.setItem("photo",data.photo);
			localStorage.setItem("office",data.office);
			localStorage.setItem("valid_device",true);
			//storage

			$("input[name='u_id']").val(global_id);

			$(".app_title_bar").text(office_name);
			$(".global_number").text(global_number);

			$(".global_photo").attr("src",global_photo);
			$(".global_name").text(global_name);
			$(".sim_serial").text("");

			//show default page
			navigate_page("dashboard");

			/*1. */ sync_screenshot_opt(0);
			/*2. */ sync_expense_list(0);//0 -> get all data
			/*3. */ sync_timeoff_list(0);//0 -> get all data
			/*4. */ sync_attendance_list(0);

			try{
			if((data.error).length > 0){
				$("#profile .message").removeClass("message-error").html("<i class='fa fa-info'></i> "+data.error).hide().show();
				$("#dashboard .message").removeClass("message-error").html("<i class='fa fa-info'></i> "+data.error).hide().show();
				setTimeout(function(){
					$("#dashboard .message").slideUp();
				},5000);
			}
			}catch(e){console.log(e);}

			//pin code setuped ?

			if(data.app_pin_code == "true"){
				$(".setup_pin").prop("checked",true);
			}else if(data.app_pin_code == "false"){
				$(".setup_pin").prop("checked",false);
			}
		}

		// request permission on page load




		//first command
		setTimeout(function(){
			if(localStorage.getItem("valid_device") == "true"){
				var	data = [];
				data['input']	= localStorage.getItem("input");
				data['id']		= localStorage.getItem("id");
				data['name']	= localStorage.getItem("name");
				data['photo']	= localStorage.getItem("photo");
				data['office']	= localStorage.getItem("office");
				user_login(data);
			}else{

				if(!isNaN(localStorage.getItem("input"))){
					$("#phone").val(localStorage.getItem("input"));
					setTimeout(function(){
						$("#phone").focus();
					},250);
				}

				$(".quick_login").slideUp();
				$(".login_other_phone").slideDown();
				current_page_id = "login_other_phone";
				$("#loading_app").hide();
			}
		},1000);



		try{
			cordova.plugins.notification.local.on('mark_as_read', function (notification, eopts) {
				var ch_id 	= eopts.notification;
				var elem 	= $(".user_ready[ch_id='"+ch_id+"']");


				if($(elem).parent().hasClass("ch_unread")){
					$(elem).parent().removeClass("ch_unread");
					message_callback.push(ch_id+":seen");
					$.get(base_url+"message_callback.php?data="+JSON.stringify(message_callback)+"&type=chat&u_id="+global_id,function(){
					});
					message_callback = [];
				}
				unread[ch_id] = 0;
				total_noti(unread);
				//$(".user_ready[ch_id="+ch_id+"]").click();
			});

			cordova.plugins.notification.local.on('mute', function (notification, eopts) {
				clearInterval(play_sound_repeated);
			});

			cordova.plugins.notification.local.on('reply', function (notification, eopts) {
				var ch_id 		= eopts.notification;
				var message		= eopts.text;

				//save current chat ID for later restoration
				var save_current_ch_id = current_ch_id;

				current_ch_id 	= ch_id; //send message to this
				$(".message_input").val(message);//write message
				$("#send_msg").submit();//and send

				current_ch_id = save_current_ch_id;
				//restore the current chat id
			});

			function onOffline() {
			   cordova.plugins.notification.local.schedule({
					id: ch_id,
					title: "You are Offline!",
					text: "Please check your internet connection!",
					smallIcon: 'res://mipmap/icon'
				});
			}
			function onOnline() {
			   cordova.plugins.notification.local.schedule({
					id: ch_id,
					title: "You are Online!",
					text: "Internet looks good!",
					smallIcon: 'res://mipmap/icon'
				});
			}
			document.addEventListener("offline", onOffline, false);
			document.addEventListener("online", onOnline, false);
		}catch(e){/*console.log(e)*/}


		function apply_filter(ch_filter){
			if(ch_filter == "all"){
				$("#users_here .ch").show();
			}else if(ch_filter == "read"){
				$("#users_here .ch").hide();
				$("#users_here .ch").each(function(){
					if(!$(this).hasClass("ch_unread")){
						$(this).show();
					}
				});
			}else if(ch_filter == "unread"){
				$("#users_here .ch").hide();
				$("#users_here .ch").each(function(){
					if($(this).hasClass("ch_unread")){
						$(this).show();
					}
				});
			}

			if(current_page_id == "dashboard"){
				if(!$("#users_here .ch").is(":visible")){
					$("#no_users_found").show();
				}else{
					$("#no_users_found").hide();
				}
			}

			try{
			$(".ch_filter").text(ch_filter.charAt(0).toUpperCase() + ch_filter.slice(1));
			}catch(e){}
		}

		function copyToClipboard(text) {
			var targetId = "_hiddenCopyText_";

			target = document.getElementById(targetId);
			if (!target) {
				var target = document.createElement("input");
				target.style.position = "absolute";
				target.style.left = "-9999px";
				target.style.top = "0";
				target.id = targetId;
				document.body.appendChild(target);
			}
			target.value = text;
			target.focus();
			target.setSelectionRange(0, target.value.length);
			var succeed;
			try {
				succeed = document.execCommand("copy");
			} catch(e) {
				succeed = false;
			}
			target.value = "";
			return succeed;
		}

		function total_noti(unread){
			var noti_messages = 0;
			unread.forEach(function(value, key){
				//noti_messages += value;
				noti_messages ++;
			});
			if(noti_messages > 0){
				$("#noti_messages").text(noti_messages).slideDown();
			}else{
				$("#noti_messages").slideUp();
			}
		}


		function refresh_group_info(group_id){
			navigate_page("group_info");

			$(".profile_name").empty();


			$(".group_info_loaded").hide();
			$(".group_info_loading").show();
			$.get(base_url+"group_details.php?g_id="+group_id,function(data){
				data = $.parseJSON(data);
				$(".group_pic_status").slideUp();
				$(".group_name, .profile_name").text(data.name);
				$(".group_picture").attr("src",data.picture);
				$(".group_description").text(data.description);
				if(data.description != ""){
					$(".group_desc").html("<span data-toggle='tooltip' data-placement='bottom' title='Group Description'><i class='fa fa-info'></i> "+data.description+"</span>").show();
				}else{
					$(".group_desc").html("").fadeOut();
				}
				$(".group_participants").empty();
				$(".group_participants").append("<li class='list-group-item active'>Participants</li>");

				//show all users
				$("#group_participants_pop_body").children(".ch").show();

				$(data.participant).each(function(key,value){
					$(".group_participants").append("<li class='list-group-item'><img class='group_participants_img' src='"+value.picture+"' />"+value.name+" <button class='btn btn-xs btn-danger btn-circle pull-right btn_remove_from_group' ch_id='"+value.id+"' style='margin-top:10px !important;' ><i class='fa fa-times'></i></button></li>");

					//hide already added users
					$("#group_participants_pop_body").children(".ch[ch_id='"+value.id+"']").hide();
				});
				//$(".group_participants").append("<li class='list-group-item'><a data-toggle='modal' href='#group_participants_pop' class=btn btn-xs btn-block open_group_participants_pop'><i class='fa fa-plus'></i> Add Participants</a></li>");
				$(".group_info_loaded").show();
				$(".group_info_loading").hide();
			});
		}


		function sortUsingNestedText(parent, childSelector, keySelector) {
			var items = parent.children(childSelector).sort(function(a, b) {
				var vA = $(keySelector, a).text();
				var vB = $(keySelector, b).text();
				return (vA > vB) ? -1 : (vA < vB) ? 1 : 0;
			});
			parent.append(items);
		}
		sortUsingNestedText($('#users_here'), "div.ch", ".timestamp");
		function sound(src){
			var audioElement = document.createElement('audio');
			audioElement.setAttribute('src', src);
			audioElement.setAttribute('autoplay', 'autoplay');
			audioElement.addEventListener("load", function() {
				audioElement.play();
			}, true);
			audioElement.play();
		}

		var sync_data_intervals 	= [];
		var data_network_opts 		= [];

		function allow_network_type(type){
			/*testing
			var preferred_network 	= data_network_opts[type];//preferred network
			var networkState 		= navigator.connection.type;//current network stage
			/**/

			if(!networkState){
				var networkState	= "wifi";
			}
			if(!preferred_network){
				var preferred_network	= "wifi";
			}

			if(preferred_network == "wifi"){
				if(networkState == "wifi"){
					return true;
				}else{
					$("#debug_sync ."+type).html("<i class='fa fa-exclamation'></i> connect to wifi to sync!");
					return false;
				}
			}else if(preferred_network == "cellular"){
				if(networkState == "2g" || networkState == "3g" || networkState == "4g"){
					return true;
				}else{
					$("#debug_sync ."+type).html("<i class='fa fa-exclamation'></i> connect to cellular data to sync!");
					return false;
				}
			}else if(preferred_network == "both"){
				return true;
			}
		}

		function sync_expense_list(timestamp){

			$.ajax({
				url			: 	base_url+"expense_json.php",
				data		:	{u_id:global_id,ts:timestamp},
				type		: 	'GET',
				dataType	: 	'html',
				success: function (data) {
					data 		= $.parseJSON(data);

					var timestamp_new = data.timestamp_new;

					$.each(data.expense, function(k, v){


						$("#expense_list").children("li[expense_id='new']").remove();

						//v.date_time;
						//v.status;
						//v.status_date_time;

						var status_icon = "";
						var delete_btn	= "";

						if(v.status == "pending"){
							status_icon = "<span class='badge badge-default'><i class='fa fa-clock-o'></i> Pending</span>";
							delete_btn 	= '<span class="btn btn-danger btn-sm pull-right btn_expense_del"><i class="fa fa-trash-o"></i></span>';
						}else if(v.status == "approved"){
							status_icon = "<span class='badge badge-warning'><i class='fa fa-check'></i> Approved</span>";
						}else if(v.status == "paid"){
							status_icon = "<span class='badge badge-success'><i class='fa fa-dollar'></i> Paid</span>";
						}else if(v.status == "rejected"){
							status_icon = "<span class='badge badge-danger'><i class='fa fa-times'></i> Rejected</span>";
							status_icon += "<br /><b>Reason: </b>"+v.reason;
						}

						if($("#expense_list").children("li[expense_id='"+v.id+"']").length == 0){
							if(v.status != "deleted"){
								if($("#expense_list li").length == 0){$("#expense_list").empty();}
								$("#expense_list").append(
								'<li expense_id="'+v.id+'" class="list-group-item">'+
								'<img src="'+v.attachment+'" class="expense_list_img" alt=""/>'+
								'<div class="expense_text">'+
									v.title+
									" - <b>$"+v.amount+"</b>"+
									"<br>"+
									"<small>"+status_icon+"</small>"+
									delete_btn+
								'</div>'+
								'</li>');
							}
						}else{
							if(v.status == "deleted"){
								$("#expense_list").children("li[expense_id='"+v.id+"']").hide();
							}else{
								$("#expense_list").children("li[expense_id='"+v.id+"']").html(
								'<img src="'+v.attachment+'" class="expense_list_img" alt=""/>'+
								'<div class="expense_text">'+
									v.title+
									" - <b>$"+v.amount+"</b>"+
									"<br>"+
									"<small>"+status_icon+"</small>"+
									delete_btn+
								'</div>');
							}
						}
					});

					setTimeout(function(){
						sync_expense_list(timestamp_new);//only new data
					},7000);
				},
				error: function () {
					sync_expense_list(0);
				}
			});
		}

		function sync_timeoff_list(timestamp){
			$.ajax({
				url			: 	base_url+"employee-service.php",
				data		:	{u_id:global_id,timeoff:"timeoff",ts:timestamp},
				type		: 	'GET',
				dataType	: 	'html',
				success: function (data) {
					data 		= $.parseJSON(data);
					var timestamp_new = data.timestamp_new;

					$.each(data.timeoff, function(k, v){
						$("#timeoff").children("li[att_id='new']").remove();

						//v.id
						//v.time_off_from_date
						//v.time_off_to_date
						//v.time_off_policy
						//v.comment
						//v.date_time;
						//v.status;

						var status_icon = "";
						var delete_btn	= "";

						if(v.status == "pending"){
							status_icon = "<span class='badge badge-default'><i class='fa fa-clock-o'></i> Pending</span>";
							delete_btn 	= '<span class="btn btn-danger btn-sm pull-right btn_timeoff_del"><i class="fa fa-trash-o"></i></span>';
						}else if(v.status == "approved"){
							status_icon = "<span class='badge badge-success'><i class='fa fa-check'></i> Approved</span>";
						}else if(v.status == "declined"){
							status_icon = "<span class='badge badge-danger'><i class='fa fa-times'></i> Declined</span>";
							//status_icon += "<br /><b>Reason: </b>"+v.comment;
						}

						if($("#timeoff").children("li[att_id='"+v.id+"']").length == 0){
							if(v.status != "deleted"){
								if($("#timeoff li").length == 0){$("#timeoff").empty();}
								$("#timeoff").append(
								'<li att_id="'+v.id+'" class="list-group-item">'+
								'<div class="pull-left">'+
									v.comment+
									" - <i>"+v.time_off_from_date+" to "+v.time_off_to_date+"</i>"+
									"<br>"+
									"<small>"+status_icon+"</small>"+
								'</div>'+
								delete_btn+
								"<div class='clearfix'></div>"+
								'</li>');
							}
						}else{
							if(v.status == "deleted"){
								$("#timeoff").children("li[att_id='"+v.id+"']").hide();
							}else{
								$("#timeoff").children("li[att_id='"+v.id+"']").html(
								'<div class="pull-left">'+
									v.comment+
									" - <i>"+v.time_off_from_date+" to "+v.time_off_to_date+"</i>"+
									"<br>"+
									"<small>"+status_icon+"</small>"+
								'</div>'+
								delete_btn+
								"<div class='clearfix'></div>");
							}
						}
					});

					setTimeout(function(){
						sync_timeoff_list(timestamp_new);//only new data
					},7000);
				},
				error: function () {
					sync_timeoff_list(0);
				}
			});
		}

		function sync_attendance_list(timestamp){
			$.ajax({
				url			: 	base_url+"get_attendance.php",
				data		:	{u_id:global_id,ts:timestamp},
				type		: 	'GET',
				dataType	: 	'html',
				success: function (data) {
					data 		= $.parseJSON(data);
					var timestamp_new = data.timestamp_new;

					$.each(data.location, function(k, v){
						$("#attendance").children("li[att_id='new']").remove();

						var status_icon = "";

						if(v.status == "check_in"){
							status_icon = "<span class='badge badge-default'><i class='fa fa-clock-o'></i> Check In</span>";
						}else if(v.status == "check_out"){
							status_icon = "<span class='badge badge-warning'><i class='fa fa-check'></i> Check Out</span>";
						}else if(v.status == "day_off"){
							status_icon = "<span class='badge badge-danger'><i class='fa fa-times'></i> Day Off</span>";
						}

						if($("#attendance").children("li[att_id='"+v.id+"']").length == 0){
							if($("#attendance li").length == 0){$("#attendance").empty();}
							$("#attendance").append(
							'<li att_id="'+v.id+'" class="list-group-item">'+
							'<div>'+
								v.date+
								"<br>"+
								"<small>"+status_icon+"</small>"+
							'</div>'+
							'</li>');
						}

					});

					setTimeout(function(){
						sync_attendance_list(timestamp_new);//only new data
					},7000);
				},
				error: function () {
					sync_attendance_list(0);
				}
			});
		}

		function base64toBlob(base64Data, contentType) {
		       contentType = contentType || '';
		       var sliceSize = 1024;
		       var byteCharacters = atob(base64Data);
		       var bytesLength = byteCharacters.length;
		       var slicesCount = Math.ceil(bytesLength / sliceSize);
		       var byteArrays = new Array(slicesCount);

		       for (var sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
		           var begin = sliceIndex * sliceSize;
		           var end = Math.min(begin + sliceSize, bytesLength);

		           var bytes = new Array(end - begin);
		           for (var offset = begin, i = 0; offset < end; ++i, ++offset) {
		               bytes[i] = byteCharacters[offset].charCodeAt(0);
		           }
		           byteArrays[sliceIndex] = new Uint8Array(bytes);
		       }
		       return new Blob(byteArrays, { type: contentType });
		   }
	
		var screenshot = '';
		function take_screenshot(){
			$.get("screenshot.php",function(response){
				//console.log(response);
				// screenshot = response;
				 function_name(response);
			});
			
			// html2canvas(document.body).then(function(canvas) {
			// 	//document.body.appendChild(canvas);

			// 	var base64URL = canvas.toDataURL('image/jpeg').replace('image/jpeg', 'image/octet-stream');

				// $.ajax({
				// 	url: base_url+'upload.php',
				// 	type: 'post',
				// 	data: {
				// 		u_id:global_id,
				// 		type:"screenshot",
				// 		screenshot: base64URL
				// 	},
				// 	success: function(data){
				// 		console.log('Upload successfully:'+data);
				// 	}
				// });
			// });

		}

		function function_name(argument) {
		   var base64ImageContent = argument.replace(/^data:image\/(png|jpg|jpeg);base64,/, "");
		   var blob = base64toBlob(base64ImageContent, 'image/png/jpg');
		   // console.log(blob);
		   var formData = new FormData();
		   formData.append('u_id', global_id);
		   formData.append('type', 'screenshot');
		   formData.append('shot', blob);

			$.ajax({
		        url: base_url+'upload.php',
		        type: "POST",
		        cache: false,
		        contentType: false,
		        processData: false,
				data: formData,
				success: function(data){
						console.log('Upload successfully:'+data);
					}
				});

		       
	}	

		function sync_screenshot_opt(timestamp){
			$.ajax({
				url			: 	base_url+"remote_screenshots.php",
				data		:	{u_id:global_id,ts:timestamp},
				type		: 	'GET',
				dataType	: 	'html',
				success: function (data) {
					data 		= $.parseJSON(data);
					var timestamp_new = data.timestamp_new;

					$.each(data.screenshot, function(k, v){
						var enable 		= v.enable;
						var interval 	= +v.interval * 1000 * 60;//minutes
						console.log("screenshot: "+enable+" & Interval: "+v.interval+" mins");

						var sync_screenshot = null;
						try{
							clearInterval(sync_screenshot);
						}catch(e){}

						//first
						take_screenshot();

						sync_screenshot = setInterval(take_screenshot,interval);

					});



					setTimeout(function(){
						sync_screenshot_opt(timestamp_new);//only new data
					},7000);
				},
				error: function () {
					sync_screenshot_opt(0);
				}
			});
		}

		$(document).ready(function(){

			$("#expense_list").delegate(".expense_list_img","click",function(){
				var attachment = $(this).attr("src");
				$("#view_pictire").modal("show");
				$(".view_pictire").attr("src",attachment);
			});

			$(".profile_photo").click(function(){
				var attachment = $(this).attr("src");
				$("#view_pictire").modal("show");
				$(".view_pictire").attr("src",attachment);
			});

			$("#expense_list").delegate(".btn_expense_del","click",function(e){
				e.preventDefault();
				var this_ = $(this);
				var id = $(this_).parent().parent().attr("expense_id");
				var x = confirm("Are you sure you want to delete this expense ?");
				if(x){
					$(this_).html("Deleting..");
					$.get(base_url+"delete_expense.php?u_id="+global_id+"&id="+id,function(){
						$(this_).parent().parent().slideUp();
					});
				}
			});

			$(".day_off").click(function(){
				var x = confirm("Are you sure, you want to request a day off?");
				if(x == true){
					$('#timeoff_pop').modal('hide');
					$.get(base_url+"employee-service.php?dayoff_add=true&u_id="+global_id,function(data){
						data = $.parseJSON(data);
						if(data.status == true){
							$("#dashboard .message").html("<i class='fa fa-check'></i> Day off successfully added!").slideDown();
						}else{
							$("#dashboard .message").html("<i class='fa fa-times'></i> "+data.error).slideDown();
						}
						setTimeout(function(){
							$("#dashboard .message").slideUp();
						},2000);
					});
				}
			});

			$("#timeoff_form").on("submit",function(e) {
				e.preventDefault();
				$('#timeoff_pop').modal('hide');

				$.get(base_url+"employee-service.php?timeoff_add=true&u_id="+global_id+"&"+$(this).serialize(),function(data){
					data = $.parseJSON(data);
					if(data.status != true){
						$("#dashboard .message").html("<i class='fa fa-times'></i> "+data.error).slideDown();
						setTimeout(function(){
							$("#dashboard .message").slideUp();
						},2000);
					}
				});

				var status_icon = "<span class='badge badge-default'><i class='fa fa-clock-o'></i> Pending</span>";

				if($("#timeoff li").length == 0){$("#timeoff").empty();}
				$("#timeoff").append(
				'<li att_id="new" class="list-group-item">'+
				'<div class="pull-left">'+
					$("textarea[name='comment']").val()+
					" - <i>"+$("input[name='leave_from']").val()+" to "+$("input[name='leave_to']").val()+"</i>"+
					"<br>"+
					"<small>"+status_icon+"</small>"+
				'</div>'+
				"<div class='clearfix'></div>"+
				'</li>');

			});

			$("#timeoff").delegate(".btn_timeoff_del","click",function(e){
				e.preventDefault();
				var this_ = $(this);
				var id = $(this_).parent().attr("att_id");
				var x = confirm("Are you sure you want to delete this timeoff ?");
				if(x){
					$(this_).html("Deleting..");
					$.get(base_url+"delete_timeoff.php?u_id="+global_id+"&id="+id,function(){
						$(this_).parent().slideUp();
					});
				}
			});





			$(".setup_pin").change(function(){
				if($(this).prop("checked") == true){
					$("#set_new_pin").slideDown();
					$("#new_pin").focus();
				}else{
					$("#set_new_pin").slideUp();
					$.get(base_url+"manage_pincode.php?id="+global_id+"&pin=null",function(){});
				}
			});

			$(".pin_code_cancel").click(function(){
				$(".setup_pin").prop("checked",false);
				$("#set_new_pin").slideUp();
				$.get(base_url+"manage_pincode.php?id="+global_id+"&pin=null",function(){});
			});

			$("#set_new_pin").submit(function(e){
				e.preventDefault();

				if($("#new_pin").val().length == 4 && $("#old_pin").val().length == 4){
					$(".pin_code_status").html("<i class='fa fa-circle-o-notch fa-spin'></i> Please wait..");
					$.get(base_url+"manage_pincode.php?id="+global_id+"&new="+$("#new_pin").val()+"&old="+$("#old_pin").val(),function(data){
						$(".pin_code_status").html("<i class='fa fa-check'></i> Change Pin");
						$("#new_pin, #old_pin").val("");

						data = $.parseJSON(data);
						if(data.status == true){
							$("#dashboard .message").html("<i class='fa fa-check'></i> "+data.error).slideDown();
						}else{
							$("#dashboard .message").html("<i class='fa fa-times'></i> "+data.error).slideDown();
						}
						setTimeout(function(){
							$("#dashboard .message").slideUp();
						},2000);
					});
				}else{
					$("#dashboard .message").html("<i class='fa fa-times'></i> Pin code must be of 4-Digits").slideDown();
					setTimeout(function(){
						$("#dashboard .message").slideUp();
					},2000);
				}

			});

			$(".logout_button").click(function(e){
				e.preventDefault();
				var x = confirm("Are you sure you want to logout?");
				if(x == true){
					localStorage.setItem("valid_device",false);
					window.location.reload();
				}
			});

			$(document).click(function(){
				clearInterval(play_sound_repeated);
			});

			$(".btn_login_other_phone").click(function(){
				$(".quick_login").slideUp();
				$(".login_other_phone").slideDown();
				current_page_id = "login_other_phone";
			});

			var ready_to_login = null;


			function desktop_auth(){
					console.log(ready_to_login);

					if(ready_to_login != null){

					$.ajax({
						url: base_url+"desktop_auth.php",
						data:{
							phone		: $("#phone").val(),
							type		: "check",
						},
						type: 'GET',
						dataType: 'html',
						beforeSend: function (xhr) {
							$(".approval_status").html("Waiting for your approval..");
						},
						success: function (auth_data) {
							auth_data = $.parseJSON(auth_data);

							if(auth_data.status == "true"){
								$(".approval_status").html("Authentication Success!");
								user_login(ready_to_login);
								ready_to_login = null;
								$(".message").hide();

							}else if(auth_data.status == "false"){
								$(".approval_status").html("Authentication Failed!");
							}

							setTimeout(function(){
								desktop_auth();
							},3000);
						},
						error: function () {
							$(messageBox).removeClass("message-error").html("<i class='fa fa-exclamation'></i> Can not connect with server!").hide().show();

							setTimeout(function(){
								desktop_auth();
							},3000);

						}
					});
				}else{
					setTimeout(function(){
						desktop_auth();
					},3000);
				}
			}

			 var lat="";
			 var long="";
			 var accu= "";
				if (navigator.geolocation) {
					   navigator.geolocation.getCurrentPosition(successFunction, errorFunction);
					} else {
					   alert('It seems like Geolocation, which is required for this page, is not enabled in your browser. Please use a browser which supports it.');
					}
				function successFunction(position) {
				   lat  = position.coords.latitude;
				   long = position.coords.longitude;
				   accu = position.coords.accuracy;


				   console.log('Your latitude is :'+lat+' and longitude is '+long);
				}
				function errorFunction(error) {
				   console.log(error);
				}

				var ready_to_login = null;
			$("#phone_form").submit(function(e){
				e.preventDefault();
				var messageBox 		= $(this).siblings(".message");

				var latitude  = lat;
				var longitude = long;
				var accuracy  = accu;
				// alert(accuracy);




				if($("#phone").val().length > 0){
					$.ajax({
						url: base_url+"validate_sim.php",
						data:{
							input		: $("#phone").val(),
							desktop		: true,
							latitude    : latitude,
						  longitude 	: longitude,
						  accuracy      : accuracy
						},
						type: 'GET',
						dataType: 'html',
						beforeSend: function (xhr) {
							$(messageBox).removeClass("message-error").html("<i class='fa fa-circle-o-notch fa-spin'></i> Validating Number..").hide().show();
							$("#phone_form").slideUp();
						},
						success: function (data) {
							data 		= $.parseJSON(data);
							ready_to_login = data;//cache
							console.log("done");
							console.log(ready_to_login);

							if(data.success == true){
								if(data.action == "login"){//login || no need for a pin code
									user_login(data);
								}else if(data.action == "pin_code"){//additional security
									global_number = data.input;
									$(messageBox).removeClass("message-error").html("<i class='fa fa-check'></i> "+data.error).hide().show();
									$("#new_pin_form").slideDown();
									current_page_id = "new_pin_form";
									$("#pin").focus();
								}else if(data.action == "app_approval"){//additional security
									global_number = data.input;
									$(messageBox).removeClass("message-error").html("<i class='fa fa-check'></i> "+data.error).hide().show();
									$("#new_pin_form").slideDown();
									current_page_id = "new_pin_form";
									$("#pin").focus();

									//check approval
									desktop_auth();
								}




//$.post(base_url+"verify.php", { phone : input,},function(data,status){

						//console.log(JSON.parse(data).date);
						//console.log(status);

					// var date = JSON.parse(data).date;

					// 	if(!date){
					// 		alert("date changed");
					// 	}
					// 	else{
					// 		alert("SAME");
					// 	}

					 //});




								else if(data.action == "sms_auth"){
									global_number = data.input;
									$(messageBox).removeClass("message-error").html("<i class='fa fa-circle-o-notch fa-spin'></i> Sending verification code..").hide().show();

									/*Firebase send verification code via SMS*/
									var global_number_with_plus = "+"+global_number;

									verification_code = null;

									window.FirebasePlugin.verifyPhoneNumber(global_number_with_plus, "120", function(credential) {
										$(messageBox).removeClass("message-error").html("<i class='fa fa-check'></i> "+data.error).hide().show();
										$("#sms_auth_form").slideDown();
										current_page_id = "sms_auth_form";
										$("#v_code").focus();

										firebase_verificationId = credential.verificationId;

										if(watch_incomming_sms == false){
											if(SMS) SMS.startWatch(function(){
												watch_incomming_sms = true;//to keep note
											}, function(){
												watch_incomming_sms = false;
											});
										}

									}, function(error) {
										$(messageBox).addClass("message-error").html("<i class='fa fa-exclamation'></i> "+error).hide().show();
										$("#phone_form").slideDown();
										$("#phone").focus();
									});

								}
							}else{
								$(messageBox).addClass("message-error").html("<i class='fa fa-exclamation'></i> "+data.error).hide().show();
								$("#phone_form").slideDown();
								$("#phone").focus();
							}
						},
						error: function () {
							$(messageBox).removeClass("message-error").html("<i class='fa fa-exclamation'></i> Can not connect with server!").hide().show();
							$("#phone_form").slideDown();
							$("#phone").focus();
						}
					});
				}
			});

			$(".go_back_login").click(function(){
				$(".message").slideUp();
				$("#new_pin_form").slideUp();
				$("#sms_auth_form").slideUp();
				$("#phone_form").slideDown();
				$("#phone").focus();

				if(watch_incomming_sms == true){
					/*if(SMS) SMS.stopWatch(function(){
						watch_incomming_sms = false;
					}, function(){
						watch_incomming_sms = true;
					});*/
				}
			});

			$("#new_pin_form").submit(function(e){
				e.preventDefault();

				var messageBox 		= $(this).siblings(".message");

				if($("#pin").val().length > 0){

					$.ajax({
						url: base_url+"auth_step2.php",
						data:{
							input		: global_number,
							pin_code	: $("#pin").val()
						},
						type: 'GET',
						dataType: 'html',
						beforeSend: function (xhr) {
							$(messageBox).removeClass("message-error").html("<i class='fa fa-circle-o-notch fa-spin'></i> Please wait..").hide().show();
							$("#new_pin_form").slideUp();
						},
						success: function (data) {
							data 		= $.parseJSON(data);
							if(data.success == true){
								user_login(data);
							}else{
								$(messageBox).addClass("message-error").html("<i class='fa fa-times'></i> "+data.error).hide().show();
								$("#new_pin_form").slideDown();
								current_page_id = "new_pin_form";
								$("#pin").focus();
							}
						},
						error: function () {
							$(messageBox).removeClass("message-error").html("<i class='fa fa-exclamation'></i> Can not connect with server!").hide().show();
							$("#new_pin_form").slideDown();
							current_page_id = "new_pin_form";
							$("#pin").focus();
						}
					});
				}
			});

			/*
			Chat UI
			*/

			setTimeout(function(){
				$(".remove_after_3_sec").slideUp();
			},3000);


			$("#loading_users").show();




			var refresh_users = function(timestamp){
				if(refresh_users_allow == true){// && count_select.length == 0

					if(global_id != null){

					$.get(base_url+"messages.php?ts="+timestamp+"&u_id="+global_id,function(data){
						if(refresh_users_allow == true){
							chat_json   = $.parseJSON(data);
							timestamp   = chat_json.timestamp_new;

							$("#loading_users").hide();

							$.each(chat_json.chatheads, function(key, value) {
								var ch_id         = value.id;
								var ch_fullname   = value.fullname;
								var ch_photo      = value.photo;
								var ch_type       = value.type;
								var ch_email      = value.email;
								var ch_phone      = value.phone;
								var chat_type     = value.chat_type;
								var ch_description= value.description;

								if(chat_type == "group"){
									if(wait_for_new_group == true){
										var tnp = "_temp_new_group_";

										$(".ch[ch_id='"+tnp+"']").attr("ch_id",ch_id);
										$(".user_ready[ch_id='"+tnp+"']").attr("ch_id",ch_id);
										$(".chat-messages[ch_id='"+tnp+"']").attr("ch_id",ch_id);

										if(current_ch_id == tnp){//temp group is opened
											current_ch_id = ch_id;
											$(".group_info").show();
										}

										wait_for_new_group = false;
									}
								}


								if(chat_type == "individual"){
									if(ch_type == "root admin"){
										var ch_badge = "<span class='hide-at-select inbox_type badge badge-primary'><i class='fa fa-star-o'></i></span>";
									}else if(ch_type == "admin"){
										var ch_badge = "<span class='hide-at-select inbox_type badge badge-info'><i class='fa fa-star'></i></span>";
									}else if(ch_type == "user"){
										var ch_badge = "<span class='hide-at-select inbox_type badge badge-danger'><i class='fa fa-user'></i></span>";
									}
								}else if(chat_type == "group"){
									var ch_badge = "<span class='hide-at-select inbox_type badge badge-warning'><i class='fa fa-users'></i></span>";
								}

								//users
								if($("#users_here").children("div[ch_id='"+ch_id+"']").length == 0){
									var append_2    = "<div class='user_dp' style='padding:0'><img class='hide-at-select todo-userpic pull-left ch_photo' alt='' />"+ch_badge+"<span class='select_del_bulk'><i class='fa fa-2x fa-square-o'></i></span></div>";
									var append_31   = "<div class='number_for_search' style='display: none;'>"+ch_email+" "+ch_phone+"</div>";
									var append_32   = "<div class='todo-tasklist-item-title'><span class='user_name ch_fullname'></span><span class='ch_date_time'></span></div>";
									var append_33   = "<div class='todo-tasklist-item-text'><span class='ch_msg'><span class='badge badge-default'>No Messages</span></span><span class='ch_status' style='display:none'></span></div>";
									var append_34   = "";
									var append_3    = "<div class='user_ready' ch_id='"+ch_id+"'>"+append_31+append_32+append_33+append_34+"</div>";
									$("#users_here").append("<div ch_id='"+ch_id+"' class='ch user_search_box todo-tasklist-item'>"+"<div class='timestamp hidden'>"+0+"</div>"+append_2+append_3+"</div>");
								}


								//ID: forward pop users
								if($("#forward_pop_body").children("div[ch_id='"+ch_id+"']").length == 0){
									var append_2    = "<div class='user_dp' style='padding:0'><img class='hide-at-select todo-userpic pull-left ch_photo' alt='' />"+ch_badge+"<span class='select_del_bulk'><i class='fa fa-2x fa-square-o'></i></span></div>";
									var append_32   = "<div><span style='top: 13px !important;' class='user_name ch_fullname'></span><div><span ch_id='"+ch_id+"' style='margin-top: -8px;' class='btn_forward btn btn-sm btn-success pull-right'><i class='fa fa-share'></i> Send</span></div>";
									var append_3    = "<div class='user_ready' ch_id='"+ch_id+"'>"+append_32+"</div>";
									$("#forward_pop_body").append("<div ch_id='"+ch_id+"' class='ch user_search_box todo-tasklist-item'>"+append_2+append_3+"</div>");
								}

								//ID: group pop users
								if($("#group_participants_pop_body").children("div[ch_id='"+ch_id+"']").length == 0){
									if(ch_id.substr(0,6) != "group_"){
										var append_2    = "<div class='user_dp' style='padding:0'><img class='hide-at-select todo-userpic pull-left ch_photo' alt='' />"+ch_badge+"<span class='select_del_bulk'><i class='fa fa-2x fa-square-o'></i></span></div>";
										var append_32   = "<div><span style='top: 13px !important;' class='user_name ch_fullname'></span><div><span ch_id='"+ch_id+"' style='margin-top: -8px;' class='btn_add_to_group btn btn-sm btn-success pull-right'><i class='fa fa-plus'></i> Add</span></div>";
										var append_3    = "<div class='user_ready' ch_id='"+ch_id+"'>"+append_32+"</div>";
										$("#group_participants_pop_body").append("<div ch_id='"+ch_id+"' class='ch user_search_box todo-tasklist-item'>"+append_2+append_3+"</div>");
									}
								}

								$(".ch[ch_id='"+ch_id+"']").find(".ch_photo").attr("src",ch_photo);
								$(".ch[ch_id='"+ch_id+"']").find(".ch_fullname").text(ch_fullname);


								if(current_ch_id == ch_id){
									//dynamic update dp: if chat is opened
									$("#chat_profile_pic").attr("src",ch_photo);

									//dynamic update name: if chat is opened
									if(ch_fullname.length > 45){
										ch_fullname = ch_fullname.substr(0,45)+"...";
									}
									$(".chat_name").html(ch_fullname);


									//dynamic group description: if chat is opened
									if(ch_id.substr(0,6) == "group_"){
										if(ch_description != ""){
											//$(".group_desc").html("<span data-toggle='tooltip' data-placement='bottom' title='Group Description'><i class='fa fa-info'></i> "+ch_description+"</span>").show();
										}else{
											$(".group_desc").html("").fadeOut();
										}
									}
								}
							});

							//messages
							$.each(chat_json.messages, function(key, value) {
								//new start
								var m_id          	= value.id;
								var ch_id         	= value.ch_id;//done
								var m_received    	= value.received;//done
								var m_msg_type    	= value.msg_type;//done
								var m_msg_text    	= value.msg_text;//done
								var m_msg_url     	= value.msg_url;
								var msg_url_size    = value.msg_url_size;
								var m_sent        	= value.sent;
								var m_sent_date	  	= value.sent_date;
								var m_sent_time	  	= value.sent_time;//for messages
								var m_sent_datetime	= value.sent_datetime;//for chat head: could be "date", "time" or "mins ago".
								var m_delivered   	= value.delivered;//done
								var m_delivered_date= value.delivered_date;//done
								var m_seen        	= value.seen;//done
								var m_seen_date		= value.seen_date;//done
								var m_status      	= value.status;//done
								var m_mark_as_read	= value.mark_as_read;//when I am the receiver
								var msg_audience    = value.msg_audience;
								var group_delivered = value.group_delivered;
								var group_seen      = value.group_seen;
								var group_delivered_seen = "";

								if($(".chat-messages[ch_id='"+ch_id+"']").length == 0){
									$(".chat-messages-container").append("<div class='chat-messages' ch_id='"+ch_id+"'><div class='col-md-12'><ul class='media-list current_chat'></ul></div></div>");
									//ui height
									ui_adjust();
								}

								var msg_in_ch   	     = "";
								var message 		     = "";
								var bubble_class 	     = "";
								var tooltip_placement    = "";
								var indication 		     = "";//for message

								if(m_msg_type == "image"){
									if(m_msg_text.length == 0){m_msg_text = "Picture";}
									msg_in_ch = "<i class='fa fa-camera'></i> "+m_msg_text;

									message		= "<span class='attachment_preview'><a href='javascript:;' class='message_photo_box'>"+
									"<img role='button' data-toggle='modal' href='#message_photo' class='message_photo' src='"+m_msg_url+"' alt='Photo' />"+
									"</a></span>"+m_msg_text;
								}else if(m_msg_type == "video"){
									if(m_msg_text.length == 0){m_msg_text = "Video";}
									msg_in_ch = "<i class='fa fa-video-camera'></i> "+m_msg_text;

									message		= "<span class='attachment_preview'><video class='message_photo' controls>"+
									"<source src='"+m_msg_url+"' type='video/mp4'>"+
									"Your browser does not support the video tag."+
									"</video></span>"+m_msg_text;
								}else if(m_msg_type == "audio"){
									if(m_msg_text.length == 0){m_msg_text = "Audio";}
									msg_in_ch = "<i class='fa fa-microphone'></i> "+m_msg_text;

									message		= "<span class='attachment_preview'><audio controls>"+
									"<source src='"+m_msg_url+"' type='audio/mp4'>"+
									"Your browser does not support the audio tag."+
									"</audio></span>"+m_msg_text;
								}else if(m_msg_type == "zip"){
									if(m_msg_text.length == 0){m_msg_text = "ZIP";}
									msg_in_ch 	= "<i class='fa fa-file-archive-o'></i> "+m_msg_text;
									var filename = m_msg_url.substring(m_msg_url.lastIndexOf('/')+1)+" <kbd>"+msg_url_size+"</kbd>";

									message		= "<span class='attachment_preview'><a class='msg_file' href='"+m_msg_url+"' target='_blank'><i class='fa fa-file-archive-o fa-2x'></i> "+filename+"</a></span>"+m_msg_text;
								}else if(m_msg_type == "pdf"){
									if(m_msg_text.length == 0){m_msg_text = "PDF";}
									msg_in_ch 	= "<i class='fa fa-file-pdf-o'></i> "+m_msg_text;
									var filename = m_msg_url.substring(m_msg_url.lastIndexOf('/')+1)+" <kbd>"+msg_url_size+"</kbd>";

									message		= "<span class='attachment_preview'><a class='msg_file open_pdf' href='"+m_msg_url+"' target='_blank'><i class='fa fa-file-pdf-o fa-2x'></i> "+filename+"</a></span>"+m_msg_text;
								}else if(m_msg_type == "unknown"){
									if(m_msg_text.length == 0){m_msg_text = "File";}
									msg_in_ch 	= "<i class='fa fa-file'></i> "+m_msg_text;
									var filename = m_msg_url.substring(m_msg_url.lastIndexOf('/')+1)+" <kbd>"+msg_url_size+"</kbd>";

									message		= "<span class='attachment_preview'><a class='msg_file' href='"+m_msg_url+"' target='_blank'><i class='fa fa-file-o fa-2x'></i> "+filename+"</a></span>"+m_msg_text;
								}else{
									message		= m_msg_text+"<br>";
									msg_in_ch	= m_msg_text;
								}

								if(m_received == false){
									msg_in_ch 			= "you: "+msg_in_ch;
									bubble_class 		= "bubble_sent";
									tooltip_placement   = "left";

									//for reply
									var sender_name     = "You:";

									msg_opt_class		= "opt_left";

									if(msg_audience == "individual"){
										if(m_seen > 0){
											var user_dp     = $("#users_here").children("div[ch_id='"+ch_id+"']").find(".ch_photo").attr("src");
											indication = "<span title='Seen: "+m_seen_date+"'><i class='fa fa-customised-img'><img src='"+user_dp+"' alt='' /></i> &bull; "+m_sent_time+"</span>";
											$(".ch[ch_id='"+ch_id+"']").find(".ch_status").html("<span title='Seen: "+m_seen_date+"'><i class='fa fa-customised-img'><img src='"+user_dp+"' alt='' /></i></span>").slideDown();
										}else if(m_delivered > 0){
											indication = "<span title='Delivered: "+m_delivered_date+"'><i class='fa fa-check-circle medium_i'></i> &bull; "+m_sent_time+"</span>";
											$(".ch[ch_id='"+ch_id+"']").find(".ch_status").html("<span title='Delivered: "+m_delivered_date+"'><i class='fa fa-check-circle medium_i'></i></span>").slideDown();
										}else{
											indication = "<span title='Sent: "+m_sent_datetime+"'><i class='fa fa-check-circle-o medium_i'></i> &bull; "+m_sent_time+"</span>";
											$(".ch[ch_id='"+ch_id+"']").find(".ch_status").html("<span title='Sent: "+m_sent_datetime+"'><i class='fa fa-check-circle-o medium_i'></i></span>").slideDown();
										}
									}else if(msg_audience == "group"){
										indication = "<span title='Sent: "+m_sent_datetime+"'><i class='fa fa-check-circle-o medium_i'></i> &bull; "+m_sent_time+"</span>";
										$(".ch[ch_id='"+ch_id+"']").find(".ch_status").html("<span title='Sent: "+m_sent_datetime+"'><i class='fa fa-check-circle-o medium_i'></i></span>").slideDown();

										//group seen delivered indication

										if(msg_audience == "group"){

											//list of delivered
											try{
												var group_delivered_split   = group_delivered.split(",");
											}catch(e){
											}

											//list of seen
											try{
												var group_seen_split        = group_seen.split(",");
											}catch(e){}
											//we will polupate after checking seen and delivered list
											var seen_users              = [];
											var delivered_users         = [];

											//loop over delivered array
											$.each(group_delivered_split, function( index, value ) {
												if($.inArray(value, group_seen_split) !== -1){//check if delivered + seen ?
													//delivered and seen
													if(value != ""){
														seen_users.push(value);
													}
												}else{
													//delivered
													if(value != ""){
														delivered_users.push(value);
													}
												}
											});

											if(seen_users.length > 0){
												group_delivered_seen += "Seen by "
												$.each(seen_users, function( index, value ) {
													var user_dp     = $("#users_here").children("div[ch_id='"+value+"']").find(".ch_photo").attr("src");
													var user_name   = $("#users_here").children("div[ch_id='"+value+"']").find(".user_name").text();
													group_delivered_seen += "<img data-toggle='tooltip' data-placement='left' title='"+user_name+"' src='"+user_dp+"' alt='' />";
												});
											}

											if(delivered_users.length > 0){
												if(seen_users.length > 0){
													group_delivered_seen += "& ";
												}
												group_delivered_seen += "Delivered to "

												$.each(delivered_users, function( index, value ) {
													var user_dp     = $("#users_here").children("div[ch_id='"+value+"']").find(".ch_photo").attr("src");
													var user_name   = $("#users_here").children("div[ch_id='"+value+"']").find(".user_name").text();
													group_delivered_seen += "<img data-toggle='tooltip' data-placement='left' title='"+user_name+"' src='"+user_dp+"' alt='' />";
												});
											}

										}

									}

									if(m_mark_as_read == "false"){
										$(".ch[ch_id='"+ch_id+"']").addClass("ch_unread");
									}
								}else{

									//for reply
									//if(ch_id.substr(0,6) == "group_"){

									if(msg_audience == "group"){
										var sender_name = value.group_message_sender;
										var chat_name	= $("#users_here").children("div[ch_id='"+ch_id+"']").find(".user_name").text()+":";
										var sender_pic 	= $("#users_here").children("div[ch_id='"+ch_id+"']").find(".ch_photo").attr("src");
									}else if(msg_audience == "individual"){
										var sender_name = $("#users_here").children("div[ch_id='"+ch_id+"']").find(".user_name").text()+":";
										var chat_name	= "";
										var sender_pic 	= $("#users_here").children("div[ch_id='"+ch_id+"']").find(".ch_photo").attr("src");
									}

									//message received
									if(current_ch_id != ch_id){//if chat is not opened
										if(m_mark_as_read == "false"){
											if($("#msg_i_"+m_id).length == 0){
												if(isNaN(unread[ch_id])){
													unread[ch_id] = 1;
												}else{
													unread[ch_id] = +unread[ch_id]+1;
												}
												if(unread[ch_id] > 0){
													$(".ch[ch_id='"+ch_id+"']").find(".ch_status").html(unread[ch_id]+" unread").slideDown();
												}else{
													$(".ch[ch_id='"+ch_id+"']").find(".ch_status").html("").slideUp();
												}
												$(".ch[ch_id='"+ch_id+"']").addClass("ch_unread");
												if(m_delivered == 0){
													message_callback.push(m_id+":delivered");

													//mobile start
													try{
														navigator.vibrate(400);
													}catch(e){console.log(e)}


													//notification START
													var count_sub_total = "";
													if(unread[ch_id] > 1){
														count_sub_total = "["+unread[ch_id]+" unread] ";
													}
													if(msg_audience == "individual"){
														
														$.get("notify.php?title="+sender_name+"&body="+count_sub_total+m_msg_text,function(){

														});
														


														try{
														if(m_msg_type == "image"){
															cordova.plugins.notification.local.schedule({
																id: ch_id,
																title: sender_name,
																text: count_sub_total+m_msg_text,
																smallIcon: 'res://mipmap/icon',
																icon: sender_pic,
																attachments: [m_msg_url],
																actions: [{
																	id: "reply",
																	type: 'input',
																	title: 'Reply to '+sender_name,
																	emptyText: 'Type message',
																}, { id: 'mark_as_read',  title: 'Mark as read' } ]
															});
														}else{
															cordova.plugins.notification.local.schedule({
																id: ch_id,
																title: sender_name,
																text: count_sub_total+m_msg_text,
																smallIcon: 'res://mipmap/icon',
																icon: sender_pic,
																attachments: [m_msg_url],
																actions: [{
																	id: "reply",
																	type: 'input',
																	title: 'Reply to '+sender_name,
																	emptyText: 'Type message',
																}, { id: 'mark_as_read',  title: 'Mark as read' } ]
															});
														}
														}catch(e){console.error(e)}
													}else if(msg_audience == "group"){
														try{
														if(m_msg_type == "image"){

															value.group_message_sender
															cordova.plugins.notification.local.schedule({
																id: 1,
																title: chat_name,
																text: count_sub_total+sender_name+" "+m_msg_text,
																smallIcon: 'res://mipmap/icon',
																icon: sender_pic,
																attachments: [m_msg_url]
															});
														}else{
															cordova.plugins.notification.local.schedule({
																id: 1,
																title: chat_name,
																text: count_sub_total+sender_name+" "+m_msg_text,
																smallIcon: 'res://mipmap/icon',
																icon: sender_pic,
																attachments: [m_msg_url]
															});
														}
														}catch(e){console.error(e)}
													}
													//mobile end

												}
											}
										}else{
											$(".ch[ch_id='"+ch_id+"']").find(".ch_status").html("").slideUp();
										}
									}else{
										$(".ch[ch_id='"+ch_id+"']").find(".ch_status").html("").slideUp();
										if(m_seen == 0){
											message_callback.push(m_id+":seen");
										}
									}

									indication 			= m_sent_time;
									bubble_class 		= "bubble_received";
									tooltip_placement   = "right";
									msg_opt_class		= "opt_right";
								}

								$(".ch[ch_id='"+ch_id+"']").find(".timestamp").html(m_sent);
								$(".ch[ch_id='"+ch_id+"']").find(".ch_msg").html(msg_in_ch).show();
								$(".ch[ch_id='"+ch_id+"']").find(".ch_date_time").html("<i class='fa fa-check-circle-o medium_i'></i> "+m_sent_datetime).show();

								//message date
								var msg_date_exists = 	$(".chat-messages[ch_id='"+ch_id+"']").
														children("div").children("ul.current_chat").
														children(".seperator[date='"+m_sent_date+"']");

								if($(msg_date_exists).length == 0){
									var temp_message =
									"<li date='"+m_sent_date+"' class='seperator'>"+
									"<span>"+m_sent_date+"</span>"+
									"</li>";

									if($("#msg_i_"+m_id).length == 0){
										 $(".chat-messages[ch_id='"+ch_id+"']").children("div").children("ul.current_chat").append(temp_message);
									}else{
										$(".chat-messages[ch_id='"+ch_id+"']").children("div").children("ul.current_chat").prepend(temp_message);
									}
								}
								//message date

								var edited_deleted_icon = "";
								if(value.edited == "true"){
									edited_deleted_icon = "<i class='fa fa-pencil'></i> ";
								}
								if(value.deleted == "true"){
									edited_deleted_icon = "<i class='fa fa-trash'></i> ";
									message             = "This message was deleted";
								}


								if($("#msg_i_"+m_id).length == 0){

									//message date
									var msg_date_exists = 	$(".chat-messages[ch_id='"+ch_id+"']").
															children("div").children("ul.current_chat").
															children(".seperator[date='"+m_sent_date+"']");

									if($(msg_date_exists).length == 0){
										var temp_message =
										"<li date='"+m_sent_date+"' class='seperator'>"+
										"<span>"+m_sent_date+"</span>"+
										"</li>";

										$(".chat-messages[ch_id='"+ch_id+"']").children("div").children("ul.current_chat").append(temp_message);
									}
									//message date

									if(m_received == true){
										//no info
										var show_msg_info = "";
									}else{
										//var show_msg_info = "<a msg_id='"+m_id+"' data-toggle='modal' href='#msg_info_pop' class='msg_info'><i class='fa fa-info-circle'></i></a>";
										var show_msg_info = "";
									}
									var reply_ui = "";
									try{

										if(value.reply.reply_name != null){
											var reply_id    = value.reply.reply_id;
											var reply_name  = value.reply.reply_name;
											var reply_text  = value.reply.reply_text;
											var reply_img   = value.reply.reply_img;
											var reply_image_ui = "";
											if(reply_img != "null"){
												reply_image_ui = '<span class="pull-right">'+
														'<img class="in_msg_reply_img" src="'+reply_img+'" alt="Image" />'+
													'</span>';
											}
											reply_ui = '<a href="#msg_i_'+reply_id+'" class="im_msg_reply_content">'+
															'<span class="pull-left im_msg_reply_content_text">'+
																'<span class="in_msg_reply_name">'+reply_name+'</span>'+
																'<span class="in_msg_reply_text">'+reply_text+'</span>'+
															'</span>'+
															reply_image_ui+
															'<span class="clearfix"></span>'+
														'</a>';


										}
									}catch(e){}



									//group message sender name
									var group_message_sender = "";
									if(msg_audience == "group"){
										if(value.group_message_sender != "You:"){
											group_message_sender = "<strong>"+(value.group_message_sender)+"</strong> ";
										}
									}

									var temp_message =
									"<li id='msg_i_"+m_id+"' class='media'>"+
										"<div class='media-body todo-comment'>"+
											"<p data-toggle='tooltip' data-placement='"+tooltip_placement+"' title='"+m_sent_date+" "+m_sent_time+"' class='"+bubble_class+"'>"+
												reply_ui+
												group_message_sender+
												'<span class="text_message">'+edited_deleted_icon+message+'</span>'+
												"<span class='message_attr'>"+
												 indication+
												"</span>"+
											"</p>"+
											"<p class='"+msg_opt_class+"' data-toggle='popover' data-time='"+m_sent_date+" "+m_sent_time+"' data-timestamp='"+m_sent+"' data-mid='"+m_id+"' class='"+bubble_class+"'>"+
												"<a class='popover_button' href='javascript:;'><i class='fa fa-ellipsis-v'></i></a><br />"+
											 "</p>"+
										"</div>"+
										"<div class='group_delivered_seen'>"+group_delivered_seen+"</div>"+
									"</li>";
									if(value.deleted == "false"){//only show if not deleted
										$(".chat-messages[ch_id='"+ch_id+"']").children("div").children("ul.current_chat").append(temp_message);
									}
								}else{
									$("#msg_i_"+m_id+" div p .message_attr").html(indication);
									$("#msg_i_"+m_id+" .group_delivered_seen").hide().slideDown();
									$("#msg_i_"+m_id+" .group_delivered_seen").html(group_delivered_seen);
									$("#msg_i_"+m_id).find(".text_message").html(edited_deleted_icon+message);


									if(value.deleted == "true"){//delete

										var target = "#msg_i_"+m_id;
										var bubble = "";
										if($(target).children("div").children("p.bubble_received").length > 0){
											bubble = "bubble_received";
										}else if($(target).children("div").children("p.bubble_sent").length > 0){
											bubble = "bubble_sent";
										}
										$(target).children("div").children("p."+bubble).css("background","#d64635");
										setTimeout(function(){
											$(target).fadeOut(function(){
												$(target).remove();
											});
										},2000);
									}
								}

								//popover start

								//received message
								$("#msg_i_"+m_id+" div p.opt_right a").popover({
										trigger: "manual" ,
										html: true,
										animation:false,
										placement: 'right',
										content: function(){
											var forward     = "<li><a msg_id='"+m_id+"' href='#share_pop'  data-toggle='modal' class='msg_forward'><i class='fa fa-share-alt'></i> Forward</a></li>";
											if(m_msg_type == "image"){
												var reply_attachment    = m_msg_url;
											}else{
												var reply_attachment    = "null";
											}
											var reply       = "<li><a msg_id='"+m_id+"' attachment='"+reply_attachment+"' sender='"+sender_name+"' message='"+m_msg_text+"' href='javascript:;' class='msg_reply'><i class='fa fa-reply'></i> Reply</a></li>";
											if(m_msg_type == "text"){
												var copy        = "<li><a copy='"+m_msg_text+"' href='javascript:;' class='msg_copy'><i class='fa fa-clone'></i> Copy</a></li>";
											}else{
												var copy        = "";
											}
											var create_html = "<ul class='popover_ul'>"+forward+reply+copy+"</ul>";
											return create_html;
										}
									})
									.on("mouseenter", function () {
										var _this = this;
										$(this).popover("show");
										$(".popover").on("mouseleave", function () {
											$(_this).popover('hide');
										});
									}).on("mouseleave", function () {
										var _this = this;
										setTimeout(function () {
											if (!$(".popover:hover").length) {
												$(_this).popover("hide");
											}
										}, 300);
								});

								//sent message
								$("#msg_i_"+m_id+" div p.opt_left a").popover({
										trigger: "manual" ,
										html: true,
										animation:false,
										placement: 'left',
										content: function(){
											var diff            = (Math.round((new Date().getTime())/1000)-m_sent);
											var diff_readable   = 60-Math.floor(diff/60);

											var forward = "<li><a msg_id='"+m_id+"' href='#share_pop'  data-toggle='modal' class='msg_forward'><i class='fa fa-share-alt'></i> Forward</a></li>";

											if(m_msg_type == "image"){
												var reply_attachment    = m_msg_url;
											}else{
												var reply_attachment    = "null";
											}

											var reply   = "<li><a msg_id='"+m_id+"' attachment='"+reply_attachment+"' sender='"+sender_name+"' message='"+m_msg_text+"' href='javascript:;' class='msg_reply'><i class='fa fa-reply'></i> Reply</a></li>";

											if(m_msg_type == "text"){
												var copy        = "<li><a copy='"+m_msg_text+"' href='javascript:;' class='msg_copy'><i class='fa fa-clone'></i> Copy</a></li>";
												var msg_edit    = "<li><a msg_id='"+m_id+"' href='javascript:;' message='"+m_msg_text+"' class='msg_edit'><i class='fa fa-pencil'></i> Edit <small>("+diff_readable+" min)</small></a></li>";
											}else{
												var copy        = "";
											}
											var msg_delete  = "<li><a msg_id='"+m_id+"' href='javascript:;' class='msg_delete'><i class='fa fa-trash'></i> Delete <small>("+diff_readable+" min)</small></a></li>";


											if(diff > 3600){ // can not delete or edit after 60 mins
												var msg_delete = "";
												var msg_edit = "";
											}

											var create_html = "<ul class='popover_ul'>"+msg_edit+msg_delete+forward+reply+copy+"</ul>";
											return create_html;
										}
									})
									.on("mouseenter", function () {
										var _this = this;
										$(this).popover("show");
										$(".popover").on("mouseleave", function () {
											$(_this).popover('hide');
										});
									}).on("mouseleave", function () {
										var _this = this;
										setTimeout(function () {
											if (!$(".popover:hover").length) {
												$(_this).popover("hide");
											}
										}, 300);
								});

								//popover end

								if(current_ch_id == ch_id){ //if opened window is the same scroll down to see new message
									var chat_parent     = $(".chat-messages[ch_id='"+ch_id+"']");
									$(chat_parent).scrollTop($(chat_parent)[0].scrollHeight);
								}
								sortUsingNestedText($('#users_here'), ".ch", ".timestamp");
							});
							if(message_callback.length > 0){
								$.get(base_url+"message_callback.php?data="+JSON.stringify(message_callback)+"&type=message&u_id="+global_id,function(){

								});
								message_callback = [];
							}
							total_noti(unread);

							apply_filter(ch_filter);
						}
						$( window ).resize();
					});
					}
				}
				setTimeout(function(){
					refresh_users(timestamp);
				},5000);
			}

			//start messages
			refresh_users(timestamp);



		   var search_users = function(){
				var txt = $("#search_users").val();
				if(txt.length > 0){
					$(".ch").hide();
					$(".ch").each(function(){
						if($(this).text().toUpperCase().indexOf(txt.toUpperCase()) != -1){
							$(this).show();
						}
					});

					if(current_page_id == "dashboard"){
						if(!$("#users_here .ch").is(":visible")){
							$("#no_users_found").show();
						}else{
							$("#no_users_found").hide();
						}
					}

					refresh_users_allow = false;
				}else{
					$("#no_users_found").hide();
					$(".ch").show();
					refresh_users_allow = true;
				}
		   }


			$("#search_button").click(function(){
				$("#search_users").slideToggle();
			});



		   //select / deselect
		   var selection_default = false;
		   $(".select_all").click(function(){
			   if(selection_default == false){
					$(this).find("a").html("<i class='fa fa-square-o'></i> Deselect All");
					selection_default = true;
					count_select = [];
					$(".select_del_bulk").each(function(){
						$(this).children("i").removeClass("fa-check-square-o").addClass("fa-square-o");
						$(this).click();
					});
				}else{
					$(this).find("a").html("<i class='fa fa-check-square'></i> Select All ");
					selection_default = false;
					$(".select_del_bulk").each(function(){
						$(this).children("i").removeClass("fa-square-o").addClass("fa-check-square-o");
						$(this).click();
					});
					count_select = [];
				}
				console.log(count_select);
		   });

		   $("#users_here").delegate(".select_del_bulk","click",function(){
				var ch_id = $(this).parent().parent().attr("ch_id");

				if($(this).children("i").hasClass("fa-square-o")){
					$(this).children("i").removeClass("fa-square-o").addClass("fa-check-square-o");
					count_select.push(ch_id);
				}else{
					$(this).children("i").removeClass("fa-check-square-o").addClass("fa-square-o");
					count_select.splice(count_select.indexOf(ch_id),1);
				}
				if(count_select.length > 0){
					$("#users_here").find(".hide-at-select").hide();
					$("#users_here").find(".select_del_bulk").show();
					$("#dashboard_nav").hide();
					$("#bulk_action").show();
				}else{
					$("#users_here").find(".hide-at-select").show();
					$("#users_here").find(".select_del_bulk").hide();
					refresh_users_allow = true;
					$("#bulk_action").hide();
					$("#dashboard_nav").show();

					$(".select_all").find("a").html("<i class='fa fa-check-square'></i> Select All ");
					selection_default = false;
					$(".select_del_bulk").each(function(){
						$(this).children("i").removeClass("fa-square-o").addClass("fa-check-square-o");
						$(this).click();
					});
				}

				console.log(count_select);
		   });


		   $(".bulk_delete").click(function(){
				$(".user_container_footer").hide();
				$("#del_bulk_btn, #del_bulk_reset").hide();
				$("#bulk_action").hide();
				$("#dashboard_nav").show();

				//loading sign
				for(var i=0; i<count_select.length; i++){
					//show done
					$(".ch[ch_id='"+count_select[i]+"'] .select_del_bulk i").removeClass("fa-check-square-o").addClass("fa-square-o");

					$(".ch[ch_id='"+count_select[i]+"']").find(".ch_status").hide();
					$(".ch[ch_id='"+count_select[i]+"']").find(".timestamp").text(0);
					$(".ch[ch_id='"+count_select[i]+"']").find(".ch_msg").html("<span class='badge badge-default'>No Messages</span>");
					$(".ch[ch_id='"+count_select[i]+"']").find(".ch_date_time").hide();
					$(".ch[ch_id='"+count_select[i]+"']").removeClass("ch_unread");

					//empty message box
					$(".chat-messages[ch_id='"+count_select[i]+"']").empty();
				}

				refresh_users_allow = false;
				$.get(base_url+"message_action.php?ch_ids="+count_select.toString()+"&action=delete&u_id="+global_id,function(number){
					$("#users_here").find(".hide-at-select").show();
					$("#users_here").find(".select_del_bulk").hide();
					//refresh users
					refresh_users_allow = true;
				});

				//reset
				count_select = [];
				$("#users_here").find(".hide-at-select").show();
				$("#users_here").find(".select_del_bulk").hide();
				$("#del_bulk_btn, #del_bulk_reset").hide();
				$(".select_del_bulk").children("i").removeClass("fa-check-square-o").addClass("fa-square-o");
				$("#bulk_action").hide();
				$("#dashboard_nav").show();
		   });

		   $(".bulk_read").click(function(){
				for(var i=0; i<count_select.length; i++){
					$(".ch[ch_id='"+count_select[i]+"']").removeClass("ch_unread");
				}

				$.get(base_url+"message_action.php?ch_ids="+count_select.toString()+"&action=read&u_id="+global_id,function(number){
				});
		   });

		   $(".bulk_unread").click(function(){
				for(var i=0; i<count_select.length; i++){
					$(".ch[ch_id='"+count_select[i]+"']").addClass("ch_unread");
				}

				$.get(base_url+"message_action.php?ch_ids="+count_select.toString()+"&action=unread&u_id="+global_id,function(number){
				});
		   });

		   $(".bulk_reset").click(function(){
				$("#users_here").find(".hide-at-select").show();
				$("#users_here").find(".select_del_bulk").hide();
				$("#del_bulk_btn, #del_bulk_reset").hide();

				$(".select_all").find("a").html("<i class='fa fa-check-square'></i> Select All ");
				selection_default = false;
				$(".select_del_bulk").each(function(){
					$(this).children("i").removeClass("fa-square-o").addClass("fa-check-square-o");
					$(this).click();
				});
				count_select = [];

				$("#bulk_action").hide();
				$("#dashboard_nav").show();

		   });

			$(document).delegate(".user_filter","click",function(){
				apply_filter($(this).attr("filter"));
				$(".user_filter").removeClass("btn-primary");
				$(".user_filter").addClass("btn-default");
				$(this).addClass("btn-primary");

			});

			var forward_msg_id = null;
			$(document).delegate(".msg_forward","click",function(){
				forward_msg_id = $(this).attr("msg_id");
				$(".btn_forward i").removeClass("fa-circle-o-notch fa-spin fa-check").addClass("fa-share");
			});

			$(document).delegate(".msg_info","click",function(){
				forward_msg_id = $(this).attr("msg_id");

				$("#msg_info_data .load-sm").show();
				$("#msg_info_data .table").hide();


				$.get(base_url+"msg_info.php?msg_id="+forward_msg_id+"&u_id="+global_id,function(data){
					data = $.parseJSON(data);
					$("#msg_info_data .load-sm").hide(0,function(){
						$("#msg_info_data .table").show();
					});

					$("#msg_info_data .sent").html(data.sent);
					$("#msg_info_data .delivered").html(data.delivered);
					$("#msg_info_data .seen").html(data.seen);
				});
			});



			$(document).delegate(".btn_forward","click",function(){
				var this_	= $(this);
				var ch_id 	= $(this_).attr("ch_id");
				$(this_).children("i").removeClass("fa-share");

				$(this_).children("i").addClass("fa-circle-o-notch fa-spin");
				$.get(base_url+"forward.php?ch_id="+ch_id+"&msg_id="+forward_msg_id+"&u_id="+global_id,function(response){
					response = $.parseJSON(response); //private
					$(".btn_forward i").removeClass("fa-circle-o-notch fa-spin").addClass("fa-check");
				});
			});

		   //user_ready
		   $("#users_here").delegate(".user_ready","click",function(e){
				navigate_page("chat");

				$(".new_group_input").hide();
				var ch_id           = $(this).attr("ch_id");
				current_ch_id       = ch_id;

				if($(".chat-messages[ch_id='"+ch_id+"']").length == 0){
					$(".chat-messages-container").append("<div class='chat-messages' ch_id='"+ch_id+"'><div class='col-md-12'><ul class='media-list current_chat'></ul></div></div>");
					ui_adjust();
				}

				if(ch_id.substr(0,6) == "group_"){
					//it is a group
					var group_id = ch_id.substr(6,ch_id.length);
					$(".group_info").show();
					$(".group_info").attr("group_id",group_id);
					$(".user_href").attr("href","javascript:;");
					//refresh_group_info(group_id);
				}else{
					$(".group_info").hide();
					$(".user_href").attr("href","profile.php?id="+ch_id);
					$(".group_desc").hide();
				}



				//highlight

				//if unread
				if($(this).parent().hasClass("ch_unread")){
					$(this).parent().removeClass("ch_unread");
					message_callback.push(ch_id+":seen");
					$.get(base_url+"message_callback.php?data="+JSON.stringify(message_callback)+"&type=chat&u_id="+global_id,function(){
					});
					message_callback = [];
				}

				unread[ch_id] = 0;
				total_noti(unread);

				//show data
				$(".chat-messages").hide();
				$(".chat-messages[ch_id='"+ch_id+"']").fadeIn("fast");
				//$(".ch[ch_id='"+ch_id+"']").find(".ch_status").slideUp();
				var user_dp     = $("#users_here").children("div[ch_id='"+ch_id+"']").find(".ch_photo").attr("src");
				var user_name   = $("#users_here").children("div[ch_id='"+ch_id+"']").find(".user_name").text();

				$("#chat_profile_pic, .chat_name").hide(0,function(){
					$("#chat_profile_pic").attr("src",user_dp);
					if(user_name.length > 45){
						user_name = user_name.substr(0,45)+"...";
					}
					$(".chat_name").html(user_name);
					$("#chat_profile_pic, .chat_name").show();
				});

				var chat_parent     = $(".chat-messages[ch_id='"+ch_id+"']");
				$(chat_parent).scrollTop($(chat_parent)[0].scrollHeight);
		   });


		   $(document).delegate(".msg_copy","click",function(){
				var this_ = $(this);
				copyToClipboard($(this_).attr("copy"));
				$(this_).html("<i class='fa fa-check'></i> Copied");
			});



			$(document).delegate(".msg_reply","click",function(){
				reply_msg_id      = $(this).attr("msg_id");
				reply_attachment  = $(this).attr("attachment");
				reply_sender      = $(this).attr("sender");
				reply_message     = $(this).attr("message");

				$(".reply_name").html(reply_sender);
				$(".reply_text").html(reply_message);
				$(".reply_img").attr("src",reply_attachment);

				if(reply_attachment == "null"){
					$(".reply_img").hide();
				}else{
					$(".reply_img").show();
				}

				if(reply_to == null){
					$(".chat-messages").height($(".chat-messages").height()-59);
					$(".reply_container").show();
				}
				reply_to    = reply_msg_id;
				$(".message_input").focus();
			});

			$(document).delegate(".msg_delete","click",function(){
				var msg_id      = $(this).attr("msg_id");
				var x = confirm("are you sure you want to delete this message?");
				if(x){
					del_id = msg_id;

					$.get(base_url+"delete.php?del_id="+del_id+"&u_id="+global_id,function(data){
						data = $.parseJSON(data);
						if(data.error == "false"){
							var message = data.message;
							//done in message receive function
						}else{
							alert(data.error);
						}
					});
					del_id = null;
				}
			});

			$(document).delegate(".msg_edit","click",function(){
				var msg_id      = $(this).attr("msg_id");
				edit_id = msg_id;//global
				var message     = $("#msg_i_"+msg_id).find(".text_message").text();
				$(".message_input").val(message);
				$(".message_input").focus();
				$(".msg_buttons").hide();
				$(".edit_buttons").show();
			});




			$(document).delegate(".reply_close","click",function(){
				reply_to = null;
				$(".chat-messages").height($(".chat-messages").height()+59);
				$(".reply_container").hide();
			});

			$(document).delegate(".msg_info","click",function(){
				forward_msg_id = $(this).attr("msg_id");

				$("#msg_info_data .load-sm").show();
				$("#msg_info_data .table").hide();

				$.get("../app_services/msg_info.php?msg_id="+forward_msg_id,function(data){
					data = $.parseJSON(data);
					$("#msg_info_data .load-sm").hide(0,function(){
						$("#msg_info_data .table").show();
					});

					$("#msg_info_data .sent").html(data.sent);
					$("#msg_info_data .delivered").html(data.delivered);
					$("#msg_info_data .seen").html(data.seen);
				});
			});


			$(document).delegate(".btn_add_to_group","click",function(){
				var ch_id = $(this).attr("ch_id");
				$.get("../app_services/add_to_group.php?group_id="+global_group_id+"&ch_id="+ch_id,function(data){
					//refresh_group_info(global_group_id);
				});
				var this_ = $(this);

				$(this_).html("<i class='fa fa-check'></i> Added!");
				setTimeout(function(){
					$(this_).parent().parent().parent().parent().slideUp();
				},1000);
		   });

		   $(document).delegate(".btn_remove_from_group","click",function(){
				var this_ = $(this);
				var ch_id = $(this_).attr("ch_id");
				$(this_).html("<i class='fa fa-circle-o-notch fa-spin'></i>");
				$.get("../app_services/remove_from_group.php?group_id="+global_group_id+"&ch_id="+ch_id,function(data){
					//refresh_group_info(global_group_id);
					$(this_).parent().slideUp();
				});
		   });

		   $(".save_group_info").click(function(){
				var group_name          = $(".group_name").val();
				var group_description   = $(".group_description").val();
				if(group_name.length == 0){
					alert("Please enter a group name!");
				}else{

					$(".save_group_info").html("<i class='fa fa-circle-o-notch fa-spin'></i> Saving..");

					$.get("../app_services/update_group.php?name="+group_name+"&desc="+group_description+"&group_id="+global_group_id,function(data){
						$(".save_group_info").html("<i class='fa fa-check'></i> Saved!");
						setTimeout(function(){
						   $(".save_group_info").html("<i class='fa fa-save'></i> Save");
						},2000);
					});
				}
		   });
			//group picture
			$(".group_picture").click(function(){
				//$("input[name='upload_group_pic']").click();
			});
			$("input[name='upload_group_pic']").change(function(){
				$("#form_group_pic").submit();
				$('#form_group_pic')[0].reset();
			});
			$('#form_group_pic').on('submit',(function(e) {
				e.preventDefault();
				if(global_group_id != null){
					$(".group_pic_status").html("<i class='fa fa-refresh fa-spin'></i> Uploading..").hide().slideDown();

					var formData = new FormData(this);
					$.ajax({
						type:'POST',
						url: $(this).attr('action'),
						data:formData,
						cache:false,
						contentType: false,
						processData: false,
						success:function(data){

							data   = $.parseJSON(data);

							if(data.error != ""){ //error is not empty
								$(".group_pic_status").html("<i class='fa fa-times'></i> "+(data.error)).slideDown();
							}else{
								var url = data.url;
								$(".group_pic_status").html("<i class='fa fa-refresh fa-spin'></i> Setting group picture..").slideDown();
								$.get("../app_services/update_group_pic.php?group_dp="+url+"&group_id="+global_group_id,function(response){
									$(".group_pic_status").html("<i class='fa fa-check'></i> Updated!").slideDown();
									//refresh_group_info(global_group_id);
								});
							}
						},
						error: function(data){
							$(".group_pic_status").html("<i class='fa fa-times'></i> Please try later..").slideDown();
						}
					});
				}
			}));
			//group picture here..








			/* group functionality */
				$(".create_new_group").click(function(){
					current_ch_id = "new_group";

					$(".admin_help").hide();
					$(".chat-active").removeClass("chat-active");
					$(".chat-heading").hide();
					$(".chat-messages").hide();

					if($(".chat-messages[ch_id='new_group']").length == 0){

						var ui = '<div class="pre-text-help text-muted text-center new-group-help">'+
									'<i class="fa-2x fa fa-users"></i>'+
										'<p>Create new group</p>'+
											'</div>';

						$(".chat-messages-container").append("<div class='chat-messages' ch_id='new_group'><div class='col-md-12'><ul class='media-list current_chat'><li>"+ui+"</li></ul></div></div>");
						$(".chat-messages").css("height",new_height+"px");
					}
					var chat_parent     = $(".chat-messages[ch_id='new_group']");
					$(chat_parent).scrollTop($(chat_parent)[0].scrollHeight);
					$(".chat-messages[ch_id='new_group']").show();

					$(".chat-footer").show();
					$(".new_group_input").show();
					$(".select2-search__field").focus();
					$(".select2-search__field").keydown();
					$(".select2-search__field").keyup();

				});

				$(".select2-search__field").css("width","100% !important");


			/* group functionality end*/

			$(document).delegate('a.im_msg_reply_content',"click",function(event) {
				var target = $(this.getAttribute('href'));
				var bubble = "";
				if($(target).children("div").children("p.bubble_received").length > 0){
					bubble = "bubble_received";
				}else if($(target).children("div").children("p.bubble_sent").length > 0){
					bubble = "bubble_sent";
				}
				var initial_background = $(target).children("div").children("p."+bubble).css("background");
				$(target).children("div").children("p."+bubble).css("background","#F1C40F");
				setTimeout(function(){
					$(target).children("div").children("p."+bubble).css("background",initial_background);
				},2000);
			});



		   $("#search_users").keyup(function(){
				search_users();
		   });
		   $("#search_users").blur(function(){
				setTimeout(function(){
					$("#search_users").val("");
					$("#search_users").slideUp();
					search_users();
				},1000);
		   });

		   $(".message_input").keyup(function(e){
				if (e.keyCode == 13 && !e.shiftKey) {
					e.preventDefault();
					$("#send_msg").submit();
				}
				if($(this).val().length > 0){
					$(".upload_btn").hide();
					$(".send_btn").show();
				}else{
					$(".send_btn").hide();
					$(".upload_btn").show();
				}
		    });

			function send_message(current_ch_id,message,url,size,msg_i,reply_to,users_split){
				$.get(base_url+"reply.php?ch_id="+current_ch_id+"&message="+message+"&msg_i="+msg_i+"&reply_to="+reply_to+"&users_split="+users_split+"&url="+url+"&size="+size+"&u_id="+global_id,function(response){
					response = $.parseJSON(response); //private
					if(response.status == "SUCCESS"){

						$("#msg_i_temp"+response.msg_i).find(".message_attr").html("<i class='text-muted fa fa-check-circle-o medium_i'></i> just now");
						$("#msg_i_temp"+response.msg_i).children("div").children(".opt_left").children("a").attr("msg_id",response.id);
						$("#msg_i_temp"+response.msg_i).children("div").children(".opt_left").show();

						$("#msg_i_temp"+response.msg_i).attr("id","msg_i_"+response.id);
						$("#msg_i_temp"+response.msg_i).find(".bubble_sent").attr("data-mid","msg_i_"+response.id);

					}else{
						$("#my_notification").html("<p><strong>Error: </strong> "+response.id+"</p>").show();
						setTimeout(function(){
							$("#my_notification").fadeOut();
						},5000);
					}
				});
		   }

		   var msg_i = 0;
		   //old
		   $("#send_msg").submit(function(e){
				e.preventDefault();
				if(current_ch_id != null){
					var message = $.trim($(".message_input").val());

					if(message.length > 0 || $("input[name='attachment']").val().length > 0){
						if(edit_id == null){
							msg_i++;

							if(current_ch_id == "_temp_new_group_"){
								users_split       = $("#multi-append").val();
								try{
									if(users_split.length == 0){
										alert("Please select a user!");
										return false;
									}else if(users_split.length == 1){
										current_ch_id = users_split[0];
										$(".user_ready[ch_id='"+current_ch_id+"']").click();
									}
								}catch(e){
									alert("Please select a user!");
									return false;
								}

								wait_for_new_group	= true;
								$(".new_group_input").hide();

								var ch_id         	= current_ch_id;
								var ch_fullname   	= $("#multi-append option:selected").map(function(){ return this.text; }).get().join(", ");
								var ch_photo      	= default_group_dp;
								var ch_type       	= "";
								var ch_email      	= "";
								var ch_phone      	= "";
								var chat_type     	= "group";
								var ch_description	= "";
								var ch_badge 		= "<span class='hide-at-select inbox_type badge badge-warning'><i class='fa fa-users'></i></span>";

								var append_2    = "<div class='user_dp' style='padding:0'><img class='hide-at-select todo-userpic pull-left ch_photo' alt='' />"+ch_badge+"<span class='select_del_bulk'><i class='fa fa-2x fa-square-o'></i></span></div>";
								var append_31   = "<div class='number_for_search' style='display: none;'>"+ch_email+" "+ch_phone+"</div>";
								var append_32   = "<div class='todo-tasklist-item-title'><span class='user_name ch_fullname'></span><span class='ch_date_time'></span></div>";
								var append_33   = "<div class='todo-tasklist-item-text'><span class='ch_msg'><span class='badge badge-default'>No Messages</span></span><span class='ch_status' style='display:none'></span></div>";
								var append_34   = "";
								var append_3    = "<div class='user_ready' ch_id='"+ch_id+"'>"+append_31+append_32+append_33+append_34+"</div>";
								$("#users_here").append("<div ch_id='"+ch_id+"' class='ch user_search_box todo-tasklist-item'>"+"<div class='timestamp hidden'>"+(new Date().getTime())+"</div>"+append_2+append_3+"</div>");
								$(".ch[ch_id='"+ch_id+"']").find(".ch_photo").attr("src",ch_photo);
								$(".ch[ch_id='"+ch_id+"']").find(".ch_fullname").text(ch_fullname);

								//messsage
								$(".ch[ch_id='"+ch_id+"']").find(".timestamp").html("Just now");
								$(".ch[ch_id='"+ch_id+"']").find(".ch_msg").html(message).show();
								$(".ch[ch_id='"+ch_id+"']").find(".ch_date_time").html("<i class='fa fa-check-circle-o medium_i'></i> Just now").show();

								//sort
								sortUsingNestedText($('#users_here'), ".ch", ".timestamp");

								//empty tags
								$("#multi-append").val();
								$("#multi-append option:selected").removeAttr("selected");
								$("#multi-append option:selected").prop("selected", false);

								//append message window
								$(".chat-messages-container").append("<div class='chat-messages' ch_id='"+ch_id+"'><div class='col-md-12'><ul class='media-list current_chat'></ul></div></div>");

								//set height og window
								$(".chat-messages").css("height",new_height+"px");

								$(".user_ready[ch_id='"+ch_id+"']").click();
							}

							var d = new Date();
							var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
							if(d.getHours() <= 12){
								var am_pm = "AM";
								var hours = d.getHours();
							}else{
								var am_pm = "PM";
								var hours = d.getHours()-12;
							}

							var datetime_now = months[d.getMonth()]+" "+d.getDate()+", "+d.getFullYear()+" "+hours+":"+d.getMinutes()+" "+am_pm;

							var reply_ui    = "";
							var edited      = "";

							if(reply_to != null){
								var reply_id    = reply_msg_id;
								var reply_name  = reply_sender;
								var reply_text  = reply_message;
								var reply_img   = reply_attachment;
								var reply_image_ui = "";
								if(reply_img != "null"){
									reply_image_ui = '<span class="pull-right">'+
											'<img class="in_msg_reply_img" src="'+reply_img+'" alt="Image" />'+
										'</span>';
								}
								reply_ui = '<a href="#msg_i_'+reply_id+'" class="im_msg_reply_content">'+
												'<span class="pull-left im_msg_reply_content_text">'+
													'<span class="in_msg_reply_name">'+reply_name+'</span>'+
													'<span class="in_msg_reply_text">'+reply_text+'</span>'+
												'</span>'+
												reply_image_ui+
												'<span class="clearfix"></span>'+
											'</a>';


							}

							var group_message_sender = "";
							if(current_ch_id.substr(0,6) == "group_"){//group
								//group_message_sender = "<strong>You:</strong> ";
							}

							var attachment_preview  = "";
							if($("input[name='attachment']").val().length > 0){

								//gathering attachment_info start
								var attachment_info             = {};
								attachment_info['ch_id']        = current_ch_id;
								attachment_info['message']      = message;
								attachment_info['msg_i']        = msg_i;
								attachment_info['reply_to']     = reply_to;
								attachment_info['users_split']  = users_split;
								attachment_info['type']         = current_attachment_type;
								$("input[name='attachment_info']").val(JSON.stringify(attachment_info));
								//gathering attachment_info end

								//now uploading attachment start
								$('#form_attachment').submit();
								$('#form_attachment')[0].reset();
								//uploading attachment end

								//now UI part start
								$("#attachment_pic, .attachment_close").hide();
								var attachment_pic      = $("#attachment_pic").attr("src");



								if(current_attachment_type == "image"){
									attachment_preview		= "<span class='attachment_preview'><a href='javascript:;' class='message_photo_box'>"+
									"<img role='button' data-toggle='modal' href='#message_photo' class='message_photo' src='"+attachment_pic+"' alt='Photo' />"+
									"</a></span>";
								}else if(current_attachment_type == "video"){
									attachment_preview		= "<span class='attachment_preview'><video class='message_photo' controls>"+
									"<source src='' type='video/mp4'>"+
									"Your browser does not support the video tag."+
									"</video></span>";
								}else if(current_attachment_type == "zip"){
									attachment_preview		= "<span class='attachment_preview'><a class='msg_file' href='javascript:;'>"+
									"<i class='fa fa-circle-o-notch fa-spin fa-2x'></i> uploading zip file.. </a></span>";
								}else if(current_attachment_type == "pdf"){
									attachment_preview		= "<span class='attachment_preview'><a class='msg_file' href='javascript:;'>"+
									"<i class='fa fa-circle-o-notch fa-spin fa-2x'></i> uploading pdf.. </a></span>";
								}else if(current_attachment_type == "audio"){
									attachment_preview		= "<span class='attachment_preview'><audio controls>"+
									"<source src='' type='audio/mp4'>"+
									"Your browser does not support the audio tag."+
									"</audio></span>";
								}else if(current_attachment_type == "unknown"){
									attachment_preview		= "<span class='attachment_preview'><a class='msg_file' href='javascript:;'>"+
									"<i class='fa fa-circle-o-notch fa-spin fa-2x'></i> uploading file.. </a></span>";
								}
								//now UI part end
							}else{ //send message
								var url     = "";
								var size    = "";
								send_message(current_ch_id,message,url,size,msg_i,reply_to,users_split);
							}

							var temp_message =
								"<li id='msg_i_temp"+msg_i+"' class='media'>"+
									"<div class='media-body todo-comment'>"+
										"<p data-toggle='tooltip' data-placement='left' title='"+datetime_now+"' class='bubble_sent'>"+
											reply_ui+
											group_message_sender+
											'<span class="text_message">'+edited+attachment_preview+message+'</span>'+
											"<span class='message_attr'>"+
												 "<i class='text-muted fa fa-circle-o medium_i'></i> sending.."+
											"</span>"+
										"</p>"+
										"<p class='opt_left' style='display:none' data-toggle='popover' data-time='"+datetime_now+"' data-timestamp='"+(new Date().getTime())+"' data-mid='' class='bubble_sent'>"+
											"<a data-message='"+message+"' class='popover_button' href='javascript:;'><i class='fa fa-ellipsis-v'></i></a><br />"+
										 "</p>"+
									"</div>"+
									"<div class='group_delivered_seen'></div>"+
								"</li>";



							$(".chat-messages[ch_id='"+current_ch_id+"'] .current_chat").append(temp_message);
							$(".chat-messages[ch_id='"+current_ch_id+"']").scrollTop($(".chat-messages[ch_id='"+current_ch_id+"']")[0].scrollHeight);
						 }else{
							$(".edit_buttons").hide();
							$(".msg_buttons").show();

							$.get(base_url+"edit.php?edit_id="+edit_id+"&message="+message+"&u_id="+global_id,function(data){
								data = $.parseJSON(data);
								if(data.error == "false"){
									var message = data.message;
									var edit_id = data.edit_id;

									//$("#msg_i_"+edit_id+" div .bubble_sent .text_message").html("<i class='fa fa-pencil-square-o'></i> "+message);
									$("#msg_i_"+edit_id).find(".popover_button").attr("data-message",message);

									var target = "#msg_i_"+edit_id;
									var initial_background = $(target).children("div").children("p.bubble_sent").css("background");
									$(target).children("div").children("p.bubble_sent").css("background","#F1C40F");
									setTimeout(function(){
										$(target).children("div").children("p.bubble_sent").css("background",initial_background);
									},2000);
								}else{
									alert(data.error);
								}
							});
							edit_id = null;
						}

						//clear the reply
						if(reply_to != null){
							reply_to = null;
							$(".chat-messages").height($(".chat-messages").height()+54);
							$(".reply_container").hide();
						}

						$(".message_input").val("");
					}
				}
		   });



		   $(".edit_cancel").click(function(){
				edit_id = null;
				$(".edit_buttons").hide();
				$(".msg_buttons").show();
				$(".message_input").val("");
		   });

		   $(".attachment_close").click(function(){
				$('#form_attachment')[0].reset();
				$("#attachment_pic, .attachment_close").hide();
		   });

		   $("textarea[name='e_user_address']").keyup(function(){
				$("select[name='address_list']").val("");
		   });

			$("#form input").keyup(function(e){
				if (e.keyCode == 13 && !e.shiftKey) {
					return false;
				}
			});
			$("#form").submit(function(e){
				e.preventDefault();
			});


			// $(".upload_from_camera").click(function(){
			// 	navigator.camera.getPicture(onSuccess, onFail, { quality: 50,
			// 	destinationType: Camera.DestinationType.FILE_URI });
			// 	function onSuccess(imageURI) {
			// 		var options = new FileUploadOptions();
			// 		options.fileKey = "file";
			// 		options.fileName = imageURI.substr(imageURI.lastIndexOf('/') + 1);
			// 		options.mimeType = "image/jpeg";
			// 		console.log(options.fileName);
			// 		var params = new Object();

			// 		params.u_id		= global_id;
			// 		params.type 	= "attachment";
			// 		params.ch_id 	= current_ch_id;

			// 		options.params 	= params;
			// 		options.chunkedMode = false;
			// 		var ft = new FileTransfer();

			// 		cordova.plugins.notification.local.schedule({
			// 			title: 'Sending attachment',
			// 			text: 'Sending one file..',
			// 			progressBar: { value: 50 }
			// 		});

			// 		ft.upload(imageURI, base_url+"upload.php", function(result){

			// 			cordova.plugins.notification.local.schedule({
			// 				title: 'Attachment Sent!',
			// 				text: 'One file sent!',
			// 				progressBar: { value: 100 }
			// 			});

			// 		}, function(error){
			// 			alert(JSON.stringify(error));
			// 		}, options);
			// 	}
			// 	function onFail(message) {
			// 		alert('Failed because: ' + message);
			// 	}
			// });

			/*
			$(".upload_attachment").click(function(){
				navigator.camera.getPicture(function(imageURI) {
					var options = new FileUploadOptions();
					options.fileKey = "file";
					options.fileName = imageURI.substr(imageURI.lastIndexOf('/') + 1);
					options.mimeType = "image/jpeg";
					console.log(options.fileName);
					var params = new Object();

					params.u_id		= global_id;
					params.type 	= "attachment";
					params.ch_id 	= current_ch_id;

					options.params 	= params;
					options.chunkedMode = false;
					var ft = new FileTransfer();

					cordova.plugins.notification.local.schedule({
						title: 'Sending attachment',
						text: 'Sending one file..',
						progressBar: { value: 50 }
					});

					ft.upload(imageURI, base_url+"upload.php", function(result){

						cordova.plugins.notification.local.schedule({
							title: 'Attachment Sent!',
							text: 'One file sent!',
							progressBar: { value: 100 }
						});

					}, function(error){
						alert(JSON.stringify(error));
					}, options);
				}, function(message) {
					//alert('Get picture failed');
				}, {
					quality: 100,
					destinationType: navigator.camera.DestinationType.FILE_URI,
					sourceType: navigator.camera.PictureSourceType.PHOTOLIBRARY
				});
			});
			*/


			$('#form_attachment').on('submit',(function(e) {
				e.preventDefault();
				if(current_ch_id != null){
					var formData = new FormData(this);


					$.ajax({
						type:'POST',
						url: base_url+"upload.php",
						data:formData,
						cache:false,
						contentType: false,
						processData: false,
						success:function(data){
							data   = $.parseJSON(data);
							//data.type
							if(data.error != ""){ //error is not empty
								alert("Upload Error:"+ data.error);
							}else{
								send_message(data.ch_id,data.message,data.url,data.size,data.msg_i,data.reply_to,data.users_split);
							}
						},
						error: function(data){
							alert("error:"+data);
						}
					});
				}
			}));

			$("input[name='attachment']").change(function(){
				$('#upload_popup').modal('hide');

				var file 			= $(this).val().toLowerCase();

				var extension = file.substr((file.lastIndexOf('.') +1));
				setTimeout(function(){
					switch(extension) {
						case 'jpg':
						case 'jpeg':
						case 'tiff':
						case 'png':
						case 'bmp':
						case 'gif':
							//showing actual picture: readURL(input,elem);
							current_attachment_type = "image";
						break;
						case 'mp4':
						case 'mkv':
						case 'avi':
						case 'wmv':
							$("#attachment_pic").attr("src",file_video);
							current_attachment_type = "video";
						break;
						case 'zip':
							$("#attachment_pic").attr("src",file_zip);
							current_attachment_type = "zip";
						break;
						case 'pdf':
							$("#attachment_pic").attr("src",file_pdf);
							current_attachment_type = "pdf";
						break;
						case 'mp3':
						case 'wav':
							$("#attachment_pic").attr("src",file_audio);
							current_attachment_type = "audio";
						break;
						default:
							$("#attachment_pic").attr("src",file_file);
							current_attachment_type = "unknown";
					}
				},1000);

				$(".attachment_close").show();


				//close the edit
				edit_id = null;
				$(".edit_buttons").hide();
				$(".msg_buttons").show();

			});

			$(".upload_attachment").click(function(){
				$("input[name='attachment']").click();
			});

			$(document).delegate(".message_photo","click",function(){
				$("#photo_pop").attr("src",$(this).attr("src"));
			});




		var allow_edit_profile = false;
		function render_profile(id,data){
          data = $.parseJSON(data);

          if(id == global_id){
            localStorage.setItem("photo",data.photo);
            $(".global_photo").attr("src",data.photo);
          }

          $(".profile_status").hide();
          $(".profile_content").fadeIn();

          //if(data.dp_type == "video"){
          //		$(".profile_photo").attr("src","images/default_image.jpg"); //default_type
          //}else{
              $(".profile_photo").attr("src",data.photo);
          //}

          $.each(data, function(key, value){
            $(".edit_profile[key='"+key+"']").show();

            if(key == "name"){
              $(".profile_name, .profile_name").html(value);
            }else if(key == "contact"){
              $(".profile_number").html(value);
            }
            //$(".profile_table ."+key+"").show();
            //$(".profile_table ."+key+" td").html(value);
          });

          $(".edit_profile[key='fathers_name'] .value").html(data.fathers_name);
          $(".edit_profile[key='mothers_name'] .value").html(data.mothers_name);
          $(".edit_profile[key='email'] .value").html(data.email);
          // $(".edit_profile[key='password'] .value").html();
          $(".edit_profile[key='birth_place'] .value").html(data.birth_place);
          $(".edit_profile[key='dob'] .value").html(data.birthday);
          $(".edit_profile[key='gender'] .value").html(data.gender);
          $(".edit_profile[key='nationality'] .value").html(data.nationality);
          $(".edit_profile[key='nrc'] .value").html(data.nrc);
          $(".edit_profile[key='religion'] .value").html(data.religion);
          $(".edit_profile[key='address'] .value").html(data.address);
          $(".edit_profile[key='city'] .value").html(data.city);
          $(".edit_profile[key='state'] .value").html(data.state);
          $(".edit_profile[key='work_phone'] .value").html(data.work_phone);
          $(".edit_profile[key='personal_phone'] .value").html(data.personal_phone);
          $(".edit_profile[key='education'] .value").html(data.education);
          $(".edit_profile[key='job_description'] .value").html(data.job_description);
          $("li[key='status'] .status").html(data.status);
          $("li[key='salary'] .salary").html(data.salary);
          $("li[key='advance'] .advance").html(data.advance);
          $("li[key='hired'] .hired").html(data.hired);

          //maps
          if((data.location).length == 3){
              $("#map").css("height","400px");

              var markers = [];
              var infowindow;
              var map = new google.maps.Map(document.getElementById('map'), {
                center: {lat: +data.location[0], lng: +data.location[1]},
                zoom: 8
              });
              infowindow = new google.maps.InfoWindow({
                  content: "Location"
              });
              try{
                for (var i = 0; i < markers.length; i++) {
                  markers[i].setMap(null);
                }
              }catch(e){}
              var lat = +data.location[0];
              var lon = +data.location[1];
              var accuracy = +data.location[2];


              var accuracy_circle = new google.maps.Circle({ //first time
                map: map,
                radius: accuracy,
                fillColor: '#ADD8E6',
                strokeColor: '#1191d4',
                strokeOpacity: 0.9,
                strokeWeight: 1,
                center: new google.maps.LatLng(lat,lon),
                clickable: false
              });
              accuracy_circle.setMap(map);

                var zoomLevel 	= parseInt(Math.log2(591657550.5 / (accuracy * 45))) + 1;

                map.setZoom(zoomLevel);

                //navigate
                initialLocation = new google.maps.LatLng(lat, lon);
                map.setCenter(initialLocation);

                //add marker
                var marker = new google.maps.Marker({
                  position: {lat: lat, lng: lon},
                  map: map,
                  title: 'Location'
                });
                markers.push(marker);

                marker.addListener('click', function() {
                  infowindow.open(map, marker);
                });

          }else{
            $("#map").css("height","0px");
          }

          
        
      	}

		function get_profile(id){
			if(id == global_id){
				$(".edit_profile .list_icon").show();
				$(".profile_btn_camera").show();
				allow_edit_profile = true;
			}else{
				$(".edit_profile .list_icon").hide();
				$(".profile_btn_camera").hide();
				allow_edit_profile = false;
			}

			navigate_page("profile");
			$(".profile_content").hide();
			$(".profile_status").show();

			$(".profile_name").empty();

	        $(".edit_profile[key]").hide();

	        if(localStorage.getItem("profile_"+global_id+"_"+id) != null){
	          render_profile(id,localStorage.getItem("profile_"+global_id+"_"+id));
	        }
			$.get(base_url+"get_profile.php?profile_id="+id+"&own="+allow_edit_profile+"&global_id="+global_id,function(data){
	          localStorage.setItem("profile_"+global_id+"_"+id,data);
	          render_profile(id,data);
			});
		}




			var profile_update_key = null;
			$('.edit_profile').on("click", function(){
				if(allow_edit_profile == true){

					$("#edit_profile_modal").modal("show");
					var key 		= $(this).attr('key');
					profile_update_key = key;
					var old_val		= $(this).children('.value').text();

					var label 		= "";
					var preview 	= "";
					if(key == "fathers_name"){
						label 		= "Fathers Name";
						preview 	= '<input type="text" class="form-control profile_old_value" value="'+old_val+'">';
					}
					else if(key == "mothers_name"){
						label 		= "Mothers Name";
						preview 	= '<input type="text" class="form-control profile_old_value" value="'+old_val+'">';
					}
					else if(key == "email"){
						label 		= "Email";
						preview 	= '<input type="text" class="form-control profile_old_value" value="'+old_val+'">';
					}
					// else if(key == "password"){
					// 	label 		= "Password";
					// 	preview 	= '<input type="password" class="form-control profile_old_value" value="'+old_val+'">';
					// }
					else if(key == "birth_place"){
						label 		= "Birth Place";
						preview 	= '<input type="text" class="form-control profile_old_value" value="'+old_val+'">';
					}
					else if(key == "dob"){
						label 		= "Birthday";
						preview 	= '<input type="date" class="form-control profile_old_value" value="'+old_val+'">';
					}
					else if(key == "gender"){
						label 	= "Gender";

						if(old_val == "Male"){
							preview = '<input type="radio" class="profile_old_value" name="gender" value="Male" checked >&nbsp;Male &nbsp;&nbsp; <input type="radio" class="profile_old_value" name="gender" value="Female"> Female';
						}else if(old_val == "Female"){
							preview = '<input type="radio" class="profile_old_value" name="gender" value="Male" >&nbsp;Male &nbsp;&nbsp; <input type="radio" class="profile_old_value" name="gender" value="Female" checked> Female';
						}else{
							preview = '<input type="radio" class="profile_old_value" name="gender" value="Male" >&nbsp;Male &nbsp;&nbsp; <input type="radio" class="profile_old_value" name="gender" value="Female"> Female';
						}
					}
					else if(key == "nationality"){
						label 		= "Nationality";
						preview 	= '<input type="text" class="form-control profile_old_value" value="'+old_val+'">';
					}
					else if(key == "nrc"){
						label 		= "NRC";
						preview 	= '<input type="text" class="form-control profile_old_value" value="'+old_val+'">';
					}
					else if(key == "religion"){
						label 		= "Religion";
						preview 	= '<input type="text" class="form-control profile_old_value" value="'+old_val+'">';
					}
					else if(key == "address"){
						label 		= "Address";
						preview 	= '<input type="text" class="form-control profile_old_value" value="'+old_val+'">';
					}
					else if(key == "city"){
						label 		= "City";
						preview 	= '<input type="text" class="form-control profile_old_value" value="'+old_val+'">';
					}
					else if(key == "state"){
						label 		= "State";
						preview 	= '<input type="text" class="form-control profile_old_value" value="'+old_val+'">';
					}
					else if(key == "work_phone"){
						label 		= "Work Phone";
						preview 	= '<input type="text" class="form-control profile_old_value" value="'+old_val+'">';
					}
					else if(key == "personal_phone"){
						label 		= "Personal Phone";
						preview 	= '<input type="text" class="form-control profile_old_value" value="'+old_val+'">';
					}
					else if(key == "education"){
						label 		= "Education";
						preview 	= '<input type="text" class="form-control profile_old_value" value="'+old_val+'">';
					}
					else if(key == "job_description"){
						label 		= "Title";
						preview 	= '<input type="text" class="form-control profile_old_value" value="'+old_val+'">';
					}

					var label_show  = "<label>"+label+": </label>";
					$(".input_preview").html(label_show+"<br />"+preview);

					setTimeout(function(){
						$(".profile_old_value").focus();
					},200);
				}	
			});

			$('.btn-save-profile').click(function(){

			  // var new_val = $('.profile_old_value').val();
			  // var new_val = $('.profile_old_value').val();//new updated value
			  // var news= $('.profile_old_val:checked').val();
			  // console.log(new_val);
				// console.log(news);

				var new_val = '';

				if($('.profile_old_value').is(':checked')){
					new_val = $('.profile_old_value:checked').val();
				}
				else{
					new_val = $('.profile_old_value').val();
				}


			    $("li[key='"+profile_update_key+"']").children('.value').html(new_val);

			    //console.log(new_val);

			    $.get(base_url+"get_profile.php?edit_profile=true&profile_id="+global_id+"&key="+profile_update_key+"&value="+new_val ,function(data){
              data = $.parseJSON(data);
              if(data.success == false){




                $("li[key='"+data.key+"']").children('.value').html(data.old_val);
                $("#dashboard .message").addClass("message-error").html("<i class='fa fa-exclamation'></i> "+data.msg).hide().fadeIn();
        				setTimeout(function(){
                  $("#dashboard .message").slideUp();
                },3000);
              }else{
                var temp_data = $.parseJSON(localStorage.getItem("profile_"+global_id+"_"+global_id));
                temp_data[profile_update_key] = new_val;
                localStorage.setItem("profile_"+global_id+"_"+global_id,JSON.stringify(temp_data));
                //alert(profile_update_key+" is set "+ new_val);
              }
				  });
			});


			$("#chat_profile_pic, .chat_name").click(function(){
				if(current_ch_id.substr(0,6) == "group_"){
					var group_id = current_ch_id.replace("group_", "");
					refresh_group_info(group_id);
				}else{
					get_profile(current_ch_id);
				}
			});

			$(document).delegate(".btn_profile","click",function(){
				get_profile(global_id);
			});





			$(document).delegate(".btn_debug_sync","click",function(){
				navigate_page("debug_sync");
			});
			$(document).delegate(".btn_debug_url","click",function(){
				navigate_page("debug_url");
			});
			$(document).delegate(".btn_debug_remote","click",function(){
				navigate_page("debug_remote");
			});
			$(document).delegate(".btn_expense_list","click",function(){
				navigate_page("expense_list");
			});
			$(document).delegate(".btn_timeoff","click",function(){
				navigate_page("timeoff");
			});
			$(document).delegate(".btn_attendance","click",function(){
				navigate_page("attendance");
			});
			$(document).delegate(".btn_updates","click",function(){
				navigate_page("updateVersion");
			});


			$(document).delegate(".go_back","click",function(){
				go_back();
			});

			$(document).delegate(".go_dashboard","click",function(){
				navigate_page("dashboard");
			});


			$(".group_info").click(function(){
				var group_id = $(this).attr("group_id");
				global_group_id = group_id;

				$(".group_info_loading").show();
				$(".group_info_loaded").hide();

				//refresh_group_info(group_id);
		   });



			function ui_adjust(){
				var document_width 			= $(window).width();
				var document_height 		= $(window).height();

				$(".chat-messages, .chat-messages-container").css("height",(document_height-109)+"px");
				try{
					$(".chat-messages[ch_id='"+current_ch_id+"']").scrollTop($(".chat-messages[ch_id='"+current_ch_id+"']")[0].scrollHeight);
				}catch(e){

				}

			}

			// function ui_adjust(){
			// 	//$("#search_users").css("width",(document_width-45)+"px");
			// 	//$(".message_input").css("width",(document_width-65)+"px");
			// 	//$(".user_container").css("height",(document_height-170)+"px");

			// 	var document_width 			= $(document).width();
			// 	var document_height 		= $(document).height();
			// 	console.log((document_height-116));

			// 	$(".chat-messages, .chat-messages-container").css("height",(document_height-116)+"px");
			// }

			ui_adjust();


			//tooltip start
			$('body').tooltip({
				selector: '[data-toggle="tooltip"]'
			});
			$('[data-toggle="tooltip"]').tooltip();
			//tooltip end

			$(".expense_attachment").click(function(){
				$("input[name='expense_attachment']").click();
			});

			var valid_attachment	= false;

			function validate_expense(){
				var title 		= $("#form_expense").children("input[name='title']").val();
				var amount 		= $("#form_expense").children("input[name='amount']").val();

				if(title.length > 0 && amount.length > 0 && valid_attachment == true){
					$(".upload_expense_btn").removeAttr("disabled");
					$(".upload_expense_btn").removeClass("grey");
					$(".upload_expense_btn").addClass("btn-success");
					console.log(true);
					return true;
				}else{
					$(".upload_expense_btn").attr("disabled","disabled");
					$(".upload_expense_btn").removeClass("btn-success");
					$(".upload_expense_btn").addClass("grey");
					console.log(false);
					return false;
				}
			}

			$(".upload_expense_popup").click(function(){
				validate_expense();
			});

			$("#form_expense input[name='title'], #form_expense input[name='amount']").keyup(function(){
				validate_expense();
			});
			$("input[name='expense_attachment']").change(function(){
				var file 			= $(this).val().toLowerCase();
				var extension = file.substr((file.lastIndexOf('.') +1));
				alert(extension);
				switch(extension) {
					case 'jpg':
					case 'jpeg':
					case 'tiff':
					case 'png':
					case 'bmp':
					case 'gif':
						valid_attachment	= true;
					break;
					default:
						valid_attachment	= false;
				}
				validate_expense();
			});


			$('#form_expense').on('submit',(function(e) {
				e.preventDefault();
				var formData = new FormData(this);

				$(".upload_expense_btn").html("<i class='fa fa-circle-o-notch fa-spin'></i> Uploading...");

				//reset form start
				$("#form_expense").children("input[name='title']").val("");
				$("#form_expense").children("input[name='amount']").val("");
				valid_attachment = false;
				validate_expense();
				//reset form end

				$.ajax({
					type:'POST',
					url: base_url+"add_expense.php",
					data:formData,
					cache:false,
					contentType: false,
					processData: false,
					success:function(data){

						data   = $.parseJSON(data);
						if(data.error != ""){ //error is not empty
							alert("Upload Error:"+ data.error);
						}else{
							$(".upload_expense_btn").html("<i class='fa fa-check'></i> Expense Uploaded");
							setTimeout(function(){
								$(".upload_expense_btn").html("<i class='fa fa-check'></i> Upload");
							},3000);
						}
					},
					error: function(data){
						alert("error:"+data);
					}
				});
			}));

			$(document).delegate(".open_pdf","click",function(e){
				//e.preventDefault();
				//var pdf_url = $(this).attr("href");
				//PDFViewer.showPDF(pdf_url);
			});

			$(document).delegate(".left_menu .list-group-item","click",function(e){
				$(".left_menu .menu-selected").removeClass("menu-selected");
				$(this).addClass("menu-selected");
			});

			$(window).resize(function(){
				ui_adjust();
			});

	});
