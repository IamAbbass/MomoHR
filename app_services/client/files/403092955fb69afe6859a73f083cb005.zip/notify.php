<?php  


include __DIR__.'/vendor/autoload.php';

use Joli\JoliNotif\Notification;
use Joli\JoliNotif\NotifierFactory;

// Create a Notifier
$notifier = NotifierFactory::create();

// Create your notification
$notification =
    (new Notification())
    ->setTitle('MomoHr')
    ->setBody('Welcome')
     ->setIcon('images/momo.png')
    //->addOption('subtitle', 'This is a subtitle') // Only works on macOS (AppleScriptNotifier)
    //->addOption('sound', 'Frog') // Only works on macOS (AppleScriptNotifier)
;

// Send it
$notifier->send($notification);

?>