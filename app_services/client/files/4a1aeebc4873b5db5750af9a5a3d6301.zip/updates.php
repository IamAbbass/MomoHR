<?php

	error_reporting(0);

	// function rmFile($filePath)
	// {
	// 	$documentUrl = $_SERVER['DOCUMENT_ROOT'];
	// 	$fileName 	 = end(explode("/", $filePath));
	// 	$fullFileUrl = $documentUrl.'/school_system/user_documents/'.$fileName;
	// 	$status = unlink($fullFileUrl);
	// 	if ($status) {
	// 		return true;
	// 	}
	// 	else{
	// 		return false;
	// 	}
	// }


 //    $len = strlen("C:/xampp/htdocs/school_system");
 //    $new_path = substr($db_path, $len, strlen($db_path)-$len); echo "  -> ".$new_path;

	// echo $new_path;

	 function get_absolute_path($path) {
        $path = str_replace(array('/', '\\'), DIRECTORY_SEPARATOR, $path);
        $parts = array_filter(explode(DIRECTORY_SEPARATOR, $path), 'strlen');
        $absolutes = array();
        foreach ($parts as $part) {
            if ('.' == $part) continue;
            if ('..' == $part) {
                array_pop($absolutes);
            } else {
                $absolutes[] = $part;
            }
        }
        return implode(DIRECTORY_SEPARATOR, $absolutes);
    }

	header('Access-Control-Allow-Origin: *');


	if(isset($_REQUEST['version'])){

		$id = $_REQUEST['version_id'];

		if (file_exists('version.txt')) {
			$version = file_get_contents('version.txt');
			 print_r($version);
		}
		else{

			$my_file = 'version.txt';
			$handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
			$data = $id;
			fwrite($handle, $data);

			
		}

	}

	


	function deleteDir($dirPath) {
		    if (! is_dir($dirPath)) {
		        throw new InvalidArgumentException("$dirPath must be a directory");
		    }
		    if (substr($dirPath, strlen($dirPath) - 1, 1) != '/') {
		        $dirPath .= '/';
		    }
		    $files = glob($dirPath . '*', GLOB_MARK);
		    foreach ($files as $file) {
		        if (is_dir($file)) {
		            deleteDir($file);
		        } else {

		            if (explode("./", $file)[1] != 'updates.php' && explode("./", $file)[1] != 'crypto.js' && explode("./", $file)[1] != 'index.html' && explode("./", $file)[1] != 'files.zip') {
		            	unlink($file);
		            }
		        }
		    }
		    rmdir($dirPath);
	}

	function mkZipSv($server_file_url)
	{

		$url = $server_file_url;
		$zip_file = "files.zip";

		$zip_resource = fopen($zip_file, "w");

		$ch_start = curl_init();
		curl_setopt($ch_start, CURLOPT_URL, $url);
		curl_setopt($ch_start, CURLOPT_FAILONERROR, true);
		curl_setopt($ch_start, CURLOPT_HEADER, 0);
		curl_setopt($ch_start, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch_start, CURLOPT_AUTOREFERER, true);
		curl_setopt($ch_start, CURLOPT_BINARYTRANSFER,true);
		curl_setopt($ch_start, CURLOPT_TIMEOUT, 1000000);
		curl_setopt($ch_start, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch_start, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch_start, CURLOPT_FILE, $zip_resource);
		$page = curl_exec($ch_start);
		if(!$page)
		{
		 echo "Error :- ".curl_error($ch_start);
		}
		curl_close($ch_start);
	}

	function create_zip_file(){
		$zip = new ZipArchive();

		$DelFilePath="files.zip";

		if(file_exists($_SERVER['DOCUMENT_ROOT']."/t/".$DelFilePath)) {

		        unlink ($_SERVER['DOCUMENT_ROOT']."/t/".$DelFilePath);

		}
		if ($zip->open($_SERVER['DOCUMENT_ROOT']."/t/".$DelFilePath, ZIPARCHIVE::CREATE) != TRUE) {
		        die ("Could not open archive");
		}
		    $zip->addFile("index.html","myfiles.html");

		// close and save archive

		$zip->close();
	}

	function extract_zip($version_id)
	{
		$zip_file = "files.zip";
		$zip = new ZipArchive;
		$extractPath = getcwd()."/";
		if($zip->open($zip_file) != "true")
		{
		 echo "Error :- Unable to open the Zip File";
		}

		$zip->extractTo($extractPath);
		$status =$zip->close();
		
		$my_file = 'version.txt';
		$handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
		$data = $version_id;
		fwrite($handle, $data);

		return $status;
	}

	if (isset($_POST['updateData'])) {

		$version_id = $_POST['version_id'];
		// $server_file_url = $_POST['file_url'];

		// if ($status) {
		deleteDir('./');
		 $status = extract_zip($version_id);


		if ($status) {
			echo json_encode("true");
		}
		else{
			echo json_encode("false");
		}

	}

	if (isset($_POST['dowloadUpdate'])) {
		create_zip_file();
		// echo $_POST['file_url'];
		$server_file_url = $_POST['file_url'];
		$status = mkZipSv($server_file_url);

		if ($status) {
			echo json_encode("true");
		}
	}

 ?>
