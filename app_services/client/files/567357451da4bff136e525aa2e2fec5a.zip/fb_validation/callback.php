<?php
	$code = $_GET['code'];
	$url = "https://graph.accountkit.com/v1.2/access_token?grant_type=authorization_code&code=".$code."&access_token=AA|<2358143771075937>|<bc2bfeb338d7efa0a9a7c9f60db08090>";
	$get = json_decode(file_get_contents($url),true);
		header('Location:home.php?access_token='.$get['access_token'].'');
?>